import numpy as np
a1=np.arange(12).reshape(3,4)

print(a1)
print("\n")
#transpose- convert row in col and col in rows
print(np.transpose(a1))
print(a1.T) # both are same syntax
print("\n")

#ravel- convert any D array to 1d array
print(a1.ravel())
