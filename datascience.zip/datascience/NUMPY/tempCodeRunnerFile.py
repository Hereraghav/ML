#SLICING - can find multiple items.
# print(a1[2:5])
# #in 2d array [row,column]
# print(a2[2,:])
# print(a2[:,3])
# print(a2[1:,1:3])  #to find 5,6 9,10
# print(a2[::2,::3])# to find 0,3,8,11
# # ::2 means 2 skip 
# print(a2[::2,1::2])# to find 1,3 9,11
# print(a2[1,0::3])# 4,7
# print(a2[:2,1: ])#123,567