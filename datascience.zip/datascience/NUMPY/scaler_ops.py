import numpy as np
#SCALER OPERATIONS
a1=np.arange(1,10) #1d array
a2=np.arange(12,dtype=float).reshape(3,4) #2d array
a3=np.arange(8).reshape(2,2,2) #3d array
a4=np.arange(1,10)

#Arithmatic +-*/
print(a1*2)
print(a1**2)
print(a1/2)

#relational 
print(a2>5)

#vector operator- when we apply 2 operations on 2 numpy array
print(a1 + a4)