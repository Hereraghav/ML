import numpy as np
a1=np.arange(10)
a2=np.arange(12).reshape(3,4)
a3=np.arange(27).reshape(3,3,3)

#Indexing -Can find any item 
# 2D ARRAY-(row,column)
print(a2[1,1])
 
# 3d array is made of 2 - 2d array
#[array,row,column]
print(a3[1,1,0])


# #SLICING - can find multiple items.
# print(a1[2:5])
# #in 2d array [row,column]
# print(a2[2,:])
# print(a2[:,3])
# print(a2[1:,1:3])  #to find 5,6 9,10
# print(a2[::2,::3])# to find 0,3,8,11
# # ::2 means 2 skip 
# print(a2[::2,1::2])# to find 1,3 9,11
# print(a2[1,0::3])# 4,7
# print(a2[:2,1: ])#123,567


#3d array is 3 2d array.
#[array,row,column]
print(a3[::2,0,::2]) # 0,2,18,20

