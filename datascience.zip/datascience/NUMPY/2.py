import numpy as np

a1=np.arange(1,10) #1d array
a2=np.arange(12,dtype=float).reshape(3,4) #2d array
a3=np.arange(8).reshape(2,2,2) #3d array

#ndim - used to know dimension of array
print(a2.ndim)
print("\n")

#shape- used to know item exists in each dimension
print(a2.shape)
print("\n")

#size- number of items
print(a2.size)
print("\n")

#itemsize- item taking size in memory
print(a3.itemsize)
print("\n")

#dtype= dataType
print(a1.dtype)
print(a2.dtype)
print(a3.dtype)

#astype- used to change data type
print(a3.astype(np.int32))