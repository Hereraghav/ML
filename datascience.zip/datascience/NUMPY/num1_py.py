import numpy as np

# 1D numpy array
a = np.array([1, 2, 3, 4])
print("1D Array:")
print(a)
print("Type of a:", type(a))
print("\n")

# 2D numpy array/matrix
b = np.array([[1, 2, 4], [5, 6, 7]])
print("2D Array:")
print(b)
print("\n")

# 3D numpy array
c = np.array([[[1, 2], [3, 4], [5, 6], [7, 8]]])
print("3D Array:")
print(c)
print("\n")

# Specifying dtype
d = np.array([1, 2.6, 4], dtype=float)
print("Array with dtype float:")
print(d)
print("\n")

# np.arange
e = np.arange(1, 10)  # Can add ,2 we will get 1, 3, 5, 7
print("Array using np.arange:")
print(e)
print("\n")

# With reshape
f = np.arange(1, 11).reshape(5, 2)
print("Reshaped array (5x2 matrix):")
print(f)
print("\n")

# np.ones and np.zeros
print("Array of ones (3x4 matrix):")
print(np.ones((3, 4)))
print("\n")

print("Array of zeros (3x4 matrix):")
print(np.zeros((3, 4)))
print("\n")

# np.random
print("Random array (3x4 matrix):")
print(np.random.random((3, 4)))
print("\n")

# np.linspace (linear space) [range, number]
print("Linearly spaced array:")
print(np.linspace(1, 12, 6))  # Generates equal distance between range and given number
print("\n")

# np.identity (Identity matrix)
print("Identity matrix (3x3):")
print(np.identity(3))  # Matrix with diagonal numbers 1 and rest are 0
print("\n")
