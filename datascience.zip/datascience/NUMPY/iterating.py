import numpy as np
a1=np.arange(10)
a2=np.arange(12).reshape(3,4)
a3=np.arange(27).reshape(3,3,3)
print(a3)
for i in a3:
    print(i) # as it is printing 3 2d array during iteration
# nditer -will convert the 2d,3d array in 1d array and will
#print 1-1 item
for i in np.nditer(a3):
    print(i) 