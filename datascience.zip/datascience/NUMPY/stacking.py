import numpy as np
a=np.arange(12).reshape(3,4)
b=np.arange(24,36).reshape(3,4)
print(b)
#Stacking means 2 array ko jodna

#horizontal stack
print(np.hstack((a,b)))
print("\n")

#vertical stack
print(np.vstack((a,b)))
print("\n")


#SPLITTING - reverse of stacking , breaking 2 array in equal size
#horizontal split- vertically divide
print(np.hsplit(b,2))

#vertical split- horizontal divide
print(np.vsplit(b,3))
