import numpy as np

# Generating a 3x3 random array and rounding it
a1 = np.random.random((3, 3))
a1 = np.round(a1 * 100)
print("3x3 Random Array (rounded):")
print(a1)
print("\n")

# Max, Min, Sum, Product
print("Maximum value in array:", np.max(a1))
print("Minimum value in array:", np.min(a1))
print("Sum of all elements in array:", np.sum(a1))
print("Product of all elements in array:", np.product(a1))
print("\n")

# Finding max in rows (axis=1) and columns (axis=0)
print("Maximum value in each row:", np.max(a1, axis=1))
print("\n")

# Statistical functions: Mean, Median, Variance, Standard Deviation
print("Mean of the array:", np.mean(a1))
print("Median of the array:", np.median(a1))
print("Variance of the array:", np.var(a1))
print("Standard Deviation of the array:", np.std(a1))
print("\n")

# Trigonometric functions: Sine
print("Sine of the array:")
print(np.sin(a1))
print("\n")

# Dot product between two matrices
B = np.arange(12).reshape(3, 4)
B1 = np.arange(12, 24).reshape(4, 3)
print("Matrix B:")
print(B)
print("\n")

print("Matrix B1:")
print(B1)
print("\n")

print("Dot product of B and B1:")
print(np.dot(B, B1))
print("\n")

# Logarithmic and Exponential functions
print("Logarithm of the array:")
print(np.log(a1))
print("\n")

print("Exponential of the array:")
print(np.exp(a1))
print("\n")

# Round, Floor, and Ceil functions
c = np.random.random((2, 3)) * 100
print("Random 2x3 Array (scaled):")
print(c)
print("\n")

print("Rounded values of the array:")
print(np.round(c))
print("\n")

print("Floor values of the array:")
print(np.floor(c))
print("\n")

print("Ceil values of the array:")
print(np.ceil(c))
print("\n")
