import numpy as np
a=np.array([1,2,3,4,np.nan,6,7])
print(a)
print(a[~np.isnan(a)]) # Inverter operator=  ~

#Np.isnan is used to find all missing values in a data 