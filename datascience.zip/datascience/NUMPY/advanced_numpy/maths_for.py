import numpy as np

#sigmoid-whose graph has a characteristic S-shaped or sigmoid curv
#formulae= ( x ) = 1 1 + e ^− x
def signmoid(array):
    return 1/(1+np.exp(-(array)))

A=np.arange(10)
print(signmoid(A),"\n")  

#mean square error - will be used in linear regression
#loss function used in LR
actual=np.random.randint(1,100,20)
predicted=np.random.randint(1,100,20)
def MSE(actual,predicted):
    return np.mean((actual-predicted)**2)

print(actual)
print(predicted)
print(MSE(actual,predicted),"\n")

#Binary cross entropy - 
# measures the performance of a classification model 
# whose output is a probability value between 0 and 1
