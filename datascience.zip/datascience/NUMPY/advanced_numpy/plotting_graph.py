import numpy as np
import matplotlib.pyplot as plt

# Generate 100 points between -10 and 10
x = np.linspace(-10, 10, 100)
y = x

# Plot the graph
plt.plot(x, y)

# Add labels and title (optional)
plt.xlabel('x')
plt.ylabel('y')
plt.title('2D Line Plot of y = x')  

# Show the plot
plt.show()

#Parabola = y=x^2
x=np.linspace(-10,10,100)
y=x**2
plt.plot(x,y)
plt.xlabel("x")
plt.ylabel("y")
plt.title("Parabola")
plt.show()

#SIN(X)
x=np.linspace(-10,10,100)
y=np.sin(x)
plt.plot(x,y)
plt.xlabel("x")
plt.ylabel("y")
plt.show()

#Xlogx
x=np.linspace(-10,10,100)
y=x*np.log(x)
plt.plot(x,y)
plt.xlabel("x")
plt.ylabel("y")
plt.show()

#sigmoid
x=np.linspace(-10,10,100)
y=1/(1+ np.exp(-x))
plt.plot(x,y)
plt.xlabel("x")
plt.ylabel("y")
plt.show()