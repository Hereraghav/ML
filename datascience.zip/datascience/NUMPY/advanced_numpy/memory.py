# #memory
# a=[i for i in range(10000000)]
# import sys # system module
# print(sys.getsizeof(a)) # output-89095160

#*******************************#
#Now using numpy
import numpy as np
import sys
a= np.arange(10000000)
print(sys.getsizeof(a)) #40000112 size reduced to 60 percent
