import numpy as np
a=np.random.randint(1,100,15)
b=np.random.randint(1,100,24).reshape(6,4)
print(f"Unsorted array: {a}") 
#np.sort(a)[::-1] for decending order sort


#np.sort
#np.sort(a,axis=,kind='quicksort'/'heapsort'/'mergesort'/'stable',order=str or list of str)
print(f"Sorted array: {np.sort(a)}")

#Np.sort(b,axis=0 ( for column wise sort -0 and for row sort-1))
print(f"Unsorted 2d array \n: {b}")
print(f"sorted 2d array \n: {np.sort(b,axis=0)}")