#broadcasting(important topic)
#It means how numpy treats array with different arithmetic operations
#Rule 1- Make array of same dimension - like 2d with 2d or 3d with 3d
#Adjust the smaller dimension to bigger
#Rule2 -if size of each dimension of 2 array dont match,dimension with size 1 
# are stretched to the size of other array
#RULE 3 -if no where it is 1 , it will give error
#Python NUMPy do this adjusting by itself
import numpy as np
a=np.arange(12).reshape(4,3)
b=np.arange(3)
print(a)
print(b)
print(a+b)

# a=np.arange(12).reshape(3,4)
# b=np.arange(3)

# print(a)
# print(b)
# print(a+b) This will give error because after broadcast array will be (3,4)(3,3) which arent equalb=np.arange(3)



