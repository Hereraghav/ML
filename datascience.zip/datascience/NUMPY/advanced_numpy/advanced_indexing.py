import numpy as np
a=np.arange(24).reshape(6,4)
print(a,"\n")
#fancy indexing
#When no pattern can be formed to fetch the number , fancy indexing is used
#we want to print 1,3,4,6 row
print(a[[0,2,3,5]],"\n")
#1 ,3,4 column
print(a[:,[0,2,3]],"\n")

#Boolean indexing - 
# Used to find number for a condition
#  like ( only even/odd number, number divisible by n)
b=np.random.randint(1,100,24).reshape(6,4) #(min,mAX,range)
print(b,"\n")

#Find number in array greater than 50
print(b[b>50]) #useful to filter

# find even numbers
print(b[b%2==0])

#find number greater than 50 and even
print(b[(b%2==0) & (b> 50)])
#used & not and because we are using boolean value.

#find number not divisible by 7
print(b[b%7!=0])
