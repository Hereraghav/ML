#concatenate is used to join two or more array
#similar like vertical and horizontal stacking. 
import numpy as np
a=np.arange(6).reshape(2,3)
b=np.arange(6,12).reshape(2,3)  
print(a,"\n")
print(b,"\n")

c=print(np.concatenate((a,b),axis=0))# row=0 and column=1