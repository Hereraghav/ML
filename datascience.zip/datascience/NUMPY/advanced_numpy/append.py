import numpy as np
a=np.arange(1,10)
print(a)
b=np.arange(12).reshape(3,4)

#np.append- adding item at end
print(np.append(a,17))

#Append on 2d array
print(b,"\n")
# np.append(b,np.ones((b.shape[row],1)),axis=1(column)or axis=0 (row))
print(np.append(b,np.ones((b.shape[0],1)),axis=1))
