# import time 
# a= [i for i in range(10000000)]
# b=[ i for i in range(10000000,20000000)]
# c=[]
# start=time.time()
# for i in range(len(a)):
#     c.append(a[i]+b[i])
# print(time.time()-start)
#********************************************************************************#
# so list speed is 4.54
#Now i will test with numPY
import numpy as np
import time
a=np.arange(10000000)
b=np.arange(10000000,20000000)
start=time.time()
c=a+b
print(time.time()-start)
#ans is 0.02 SECONDS only