import numpy as np

#np.uniform is used to generate random numbers from a uniform distribution within a specified range.

# Generate 5 random numbers between 0 and 1
random_numbers = np.random.uniform(0, 1, 5)
print("Random numbers between 0 and 1:", random_numbers)

# Generate 5 random numbers between -10 and 10
random_numbers = np.random.uniform(-10, 10, 5)
print("Random numbers between -10 and 10:", random_numbers)
