import numpy as np
#Unique method is used to find unique items from an array
e=np.array([12,1,1,1,12,4,5,3,4,3,4,5])
print(e,'\n')
print("Unique items : ", np.unique(e),'\n')

#np.Expand_dims- expand dimension, used to expand an array
#used to convert 1d to 2d or 3d to 4d 
a=np.arange(12)
print(a)
print(np.expand_dims(a,axis=1))
 #0 for row 1 for col
# print(a.shape,"\n")
# print("EXPAND DIMS shape :","\n")
