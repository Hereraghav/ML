import numpy as np
# np.nonzero returns the indices of the elements that are non-zero in the array

# Create an array with some zero and non-zero elements
array = np.array([0, 2, 0, 3, 4, 0, 5])
print("Original array:", array)

# Get the indices of non-zero elements
non_zero_indices = np.nonzero(array)
print("Indices of non-zero elements:", non_zero_indices)

# Get the non-zero elements
non_zero_elements = array[non_zero_indices]
print("Non-zero elements:", non_zero_elements)
