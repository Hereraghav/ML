import numpy as np
a=np.random.randint(1,100,15)

#np.argmax()- finds max element index in array
#np.argmin()- finds min element index in array
print("Array is : ",a)
print("Max item in array is at : ",np.argmax(a))
print("Min item in array is at : ", np.argmin(a))
print("\n")

#0- col ,1 -row
b=np.random.randint(1,100,15).reshape(3,5)  
print("Array is : \n",b)
print("Max item in 2d array is at : ",np.argmax(b,axis=0))
print("Min item in  2d array is at : ", np.argmin(b,axis=1))
print("\n")