#HISTOGRAM- is a frequency chart
#np.histogram(Name,bins=[0,10,20,30,40....])

import numpy as np
a=np.random.randint(1,50,15)
print(a)
print(np.histogram(a,bins=[0,10,20,30,40,50]))