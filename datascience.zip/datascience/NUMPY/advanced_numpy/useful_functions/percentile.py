#np.percentile - used to calculate  the nth percentile of given data
import numpy as np
marks=np.random.randint(10,100,15)
print("Marks are  : ",marks)
print("Max percentile is : ",np.percentile(marks,100))