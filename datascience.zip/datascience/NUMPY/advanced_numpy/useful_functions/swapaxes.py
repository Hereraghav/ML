import numpy as np

# np.swapaxes is used to interchange two axes of a NumPy array.

# Create a 3D array
array = np.array([[[0, 1], [2, 3]], [[4, 5], [6, 7]]])
print("Original array:\n", array)

# Swap axes 0 and 1
swapped_array = np.swapaxes(array, 0, 1)
print("Swapped array (axes 0 and 1):\n", swapped_array)
