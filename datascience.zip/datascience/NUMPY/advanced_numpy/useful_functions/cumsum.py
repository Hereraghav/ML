#cumsum- cumulative sum
import numpy as np
a=np.random.randint(1,100,10)
print("Array:   ",a)
print("Cumulative sum : ",np.cumsum(a),"\n")
#cumprod - do cumulative product
print("Cumulative PRODUCT : ",np.cumprod(a),"\n")

#ON 2D ARRAY
b=np.random.randint(1,100,12).reshape(3,4)
print("2D ARRAY : \n",b)

print("Cumulative 2d array: \n",np.cumsum(b,axis=0))

