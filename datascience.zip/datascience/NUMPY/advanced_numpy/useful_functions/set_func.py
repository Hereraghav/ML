#Set functions
import numpy as np
a=np.array([1,2,3,4,5])
b=np.array([3,4,5,6,7])

print(a)
print(b,"\n")
#np.union1d- print union of both 
print("Union: ",np.union1d(a,b)) #Union:  [1 2 3 4 5 6 7]
#np.intersect- intersection point
print("Intersect :",np.intersect1d(a,b)) # 3 , 4 , 5
#np.setdiff -item that are in a but not in b
print("setdiff:",np.setdiff1d(a,b)) # 1 2
#np.setxor- unique item from both set
print("Setxor : ",np.setxor1d(a,b)) #1267
#np.in1d - check that item is there in set or not
print("Set in :",np.in1d(a,1)) #set in : [ True False False False False]

