#Coorelation Coefficient- tell how 2 quantites are co -related
import numpy as np
salary=np.array([25000,40000,80000,120000,200000,350000])
experience=np.array([0,1,2,1,3,6])

# print(np.corrcoef(salary,experience)) #corcoef always lies from 0-1
#Calculating the correlation coefficient
correlation_matrix = np.corrcoef(salary, experience)

print("Correlation Matrix:\n", correlation_matrix)
print("Correlation Coefficient:", correlation_matrix[0, 1])