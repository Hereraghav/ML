#np.where is used to return the indices  of elements in given input array
#  where given condition is satisfied.
import numpy as np
a=np.random.randint(10,100,20)

print("All elements in A : ", a)
print(np.where(a>50)) #will return index position

#replace all values greater than 50 with 0
# np.where(condition,True,False)
print(np.where(a>50,0,a) )