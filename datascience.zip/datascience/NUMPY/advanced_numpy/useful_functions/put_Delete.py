#Put -used to replace certain item at any index
import numpy as np
a=np.random.randint(1,100,10)

print(a)
#np.put(name,[index],[value])
np.put(a,[0,1],[330,331])
print("changed: ",a)

#Delete- delete mention value at any index
# np.delete(name,[index])
print(np.delete(a,[0,2,3,7,5]))
