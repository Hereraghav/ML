print("EXPAND DIMS shape :","\n")
