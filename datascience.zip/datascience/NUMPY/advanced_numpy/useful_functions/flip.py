# FLIP
import numpy as np
array=np.array([10,20,30,40,50,60,70,80])
print("Actual :" , array)
print("Inverted array: ",np.flip(array),"\n")

#flip on 2d array
a=np.random.randint(1,50,12).reshape(3,4)
print("2d ARRAY \n: ",a)
print("Inverted array :\n ",np.flip(a,axis=0))
#row flip=1 or column flip=0