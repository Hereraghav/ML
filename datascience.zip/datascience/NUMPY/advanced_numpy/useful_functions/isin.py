#np.isin = used to check multiple items in an array
import numpy as np
a=np.array([2,3,5,3,5,7,5,3,66,24,23,64,23,42,5,2])
item=[2,4,5,6,23,45,64]
print("ARRAY : ",a)
print("Check: ",np.isin(a,item  ))