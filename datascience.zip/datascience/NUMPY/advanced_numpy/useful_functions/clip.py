import numpy as np
a=np.random.randint(1,500,15)
print("Array : ", a)

#np.clip(name,name_min=,name_max=) - used to trim min and max values in given array
print(np.clip(a,a_min=5,a_max=35))