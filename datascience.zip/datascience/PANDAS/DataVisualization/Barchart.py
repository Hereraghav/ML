import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Bar Chart
#-Bivariate analysis , Numericcal vs categorical , aggregate analysis of group
x=[10,20,50,24,35]
color=['red','yellow','green','blue','pink']
# plt.bar(color,x,color='blue')  
# plt.show() 

best=pd.read_csv('D:\\PANDAS\\datasets\\DataVisualization\\batsman_season_record.csv')
# print(best)
# plt.bar(best['batsman'],best['2015'])
# plt.show()

#MULTIPLOT
plt.figure()
plt.bar(np.arange(best.shape[0])-0.2,best['2015'],width=0.2)
plt.bar(np.arange(best.shape[0]),best['2016'],width=0.2)
plt.bar(np.arange(best.shape[0])+0.2,best['2017'],width=0.2)

plt.xticks(np.arange(best.shape[0]),best['batsman'])
plt.show()

#Problem overlapping
y=[10,20,50,24,35]
colors=['red red red red ','yellow yellow yellow ','green green green','blue blue blue','pink pink pink']
plt.figure()
plt.bar(colors,y)
plt.xticks(rotation='vertical')# solves the problem of overlapping
plt.show()

#STACKED BAR CHART
plt.figure()
plt.bar(best['batsman'],best['2015'],label='2015')
plt.bar(best['batsman'],best['2016'],bottom=best['2015'],label='2016')    
plt.bar(best['batsman'],best['2017'],bottom=best['2015']+best['2016'],label='2017')
# Adding labels and title
plt.xlabel('Batsman')
plt.ylabel('Runs')
plt.title('Stacked Bar Chart of Runs by Year')
plt.legend(loc='upper left')
plt.show()

