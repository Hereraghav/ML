import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

# Distribution plots - used for univariate analysis, range of observation

# Load the tips dataset
tips = sns.load_dataset('tips')

# 1. Univariate histogram using histplot
plt.figure(figsize=(10, 6))
sns.histplot(data=tips, x='total_bill')
plt.title('Univariate Histogram of Total Bill')
plt.xlabel('Total Bill')
plt.ylabel('Frequency')
plt.show()

# 2. Univariate histogram using displot (figure-level)
sns.displot(data=tips, x='total_bill', kind='hist', height=6, aspect=1.5)
plt.title('Univariate Histogram of Total Bill using displot')
plt.show()

# 3. Histogram with specified number of bins
sns.displot(data=tips, x='total_bill', kind='hist', bins=20, height=6, aspect=1.5)
plt.title('Histogram of Total Bill with 20 Bins')
plt.show()

# 4. Histogram on categorical data
sns.displot(data=tips, x='day', kind='hist', height=6, aspect=1.5)
plt.title('Histogram of Days')
plt.show()  # Acting like countplot

# 5. Histogram with hue parameter
sns.displot(data=tips, x='tip', kind='hist', hue='sex', height=6, aspect=1.5)
plt.title('Histogram of Tips by Sex')
plt.show()

# 6. Facet grid - separate graphs for categorical differences
sns.displot(data=tips, x='tip', kind='hist', col='sex', element='step', height=6, aspect=1)
plt.title('Histogram of Tips by Sex (Facet Grid)')
plt.show()

# 7. KDE plot (Kernel Density Estimation) - using Gaussian kernel
plt.figure(figsize=(10, 6))
sns.kdeplot(data=tips, x='total_bill')
plt.title('Kernel Density Estimation of Total Bill')
plt.xlabel('Total Bill')
plt.ylabel('Density')
plt.show()

# 8. KDE plot with hue and fill
sns.displot(data=tips, x='total_bill', kind='kde', hue='sex', fill=True, height=6, aspect=1.5)
plt.title('Kernel Density Estimation of Total Bill by Sex')
plt.show()

# 9. Rug plot - plot marginal distribution by drawing ticks along x and y axis
plt.figure(figsize=(10, 6))
sns.kdeplot(data=tips, x='total_bill')
sns.rugplot(data=tips, x='total_bill')
plt.title('Kernel Density Estimation with Rug Plot')
plt.xlabel('Total Bill')
plt.ylabel('Density')
plt.show()

# 10. Bivariate histogram
plt.figure(figsize=(10, 6))
sns.histplot(data=tips, x='total_bill', y='tip')
plt.title('Bivariate Histogram of Total Bill and Tip')
plt.xlabel('Total Bill')
plt.ylabel('Tip')
plt.show()

# 11. Bivariate KDE plot
plt.figure(figsize=(10, 6))
sns.kdeplot(data=tips, x='total_bill', y='tip')
plt.title('Bivariate KDE Plot of Total Bill and Tip')
plt.xlabel('Total Bill')
plt.ylabel('Tip')
plt.show()

# Loading Titanic dataset from seaborn for further analysis
titanic = sns.load_dataset('titanic')
