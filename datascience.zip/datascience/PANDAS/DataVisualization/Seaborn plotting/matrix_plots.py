import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

# Heatmap plot - rect data as color encoded matrix
gap = px.data.gapminder()
x = gap.pivot(index='country', columns='year', values='lifeExp')

# Plot heatmap
plt.figure(figsize=(15, 15))
sns.heatmap(x, cmap='viridis')
plt.title('Global Life Expectancy Heatmap')
plt.show()

# Annotated heatmap for Europe
euro = gap[gap['continent'] == 'Europe'].pivot(index='country', columns='year', values='lifeExp')
plt.figure(figsize=(15, 15))
sns.heatmap(euro, cmap='viridis', annot=True, fmt='.1f')
plt.title('Life Expectancy in Europe')
plt.show()

# Clustermap for Europe
sns.clustermap(euro, cmap='viridis', annot=True, figsize=(15, 15))
plt.title('Cluster Map of Life Expectancy in Europe')
plt.show()
