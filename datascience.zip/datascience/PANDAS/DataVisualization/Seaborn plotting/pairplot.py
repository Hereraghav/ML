import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

iris=sns.load_dataset('iris')
tips=sns.load_dataset("tips")
# print(iris.head())

#Pairplot- used to pplot numerical categories
#plots will be scatter and diagonally bar
sns.pairplot(iris,hue='species')
plt.show()

#plotgrid
#we can change plots
g=sns.PairGrid(data=iris,hue='species')
g.map_diag(sns.violinplot)
g.map_upper(sns.kdeplot)
g.map_lower(sns.barplot)
g.map_offdiag(sns.scatterplot)
plt.show()

#Jointplot
sns.jointplot(data=tips,x='total_bill',y='tip',kind='reg')
plt.show()

#JOintgrid
g=sns.JointGrid(data=tips,x='total_bill',y='tip')
g.plot(sns.kdeplot,sns.violinplot)
plt.show(s)