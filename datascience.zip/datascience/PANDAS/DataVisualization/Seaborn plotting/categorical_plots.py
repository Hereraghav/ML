import numpy as np
import seaborn as sns
import plotly.express as px
import matplotlib.pyplot as plt

tips=sns.load_dataset('tips')

#Strip plot- 1 catgorical col and 1 numerical col
#axes level function
sns.stripplot(data=tips,x='day', y='total_bill',jitter=False)
#jitter remove noise
plt.show()

#Using catplot
#figure level function
sns.catplot(data=tips,x='day',y='total_bill',kind='strip',hue='sex')
plt.show() 

#swarmplot
sns.catplot(data=tips,x='day',y='total_bill',kind='swarm')
plt.show()

#BOXPLOT- distribution of data based on 5 number summary
#It also tell if it is symmetrical
#axes level
sns.boxplot(data=tips,x='sex',y='total_bill')
plt.show()

#figure level boxplot
sns.catplot(data=tips,x='day',y='total_bill',kind='box',hue='sex')
plt.show()

#Voilenplot( boxplot+kdeplot)
sns.violinplot(data=tips,x='day',y='total_bill')    
plt.show()
#or 
#fig level
sns.catplot(data=tips,x='day',y='total_bill',kind='violin',hue='sex',split=True)
plt.show()

#BARPLOT
#default is mean , we can use estimator=np.min/max
sns.barplot(data=tips,x='sex',y='total_bill',hue='smoker',estimator=np.min)
plt.show()

#PointPlot- focus on diff
sns.pointplot(data=tips,x='smoker',y='total_bill',hue='sex',estimator=np.min)
plt.show()

#Countplot
sns.countplot(data=tips,x='sex',hue='day')
plt.show()
 
