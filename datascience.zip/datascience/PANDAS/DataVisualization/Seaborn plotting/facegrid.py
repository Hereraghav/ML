import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load the tips dataset
tips = sns.load_dataset('tips')

# Facet plot using catplot (figure-level function)
sns.catplot(data=tips, x='sex', y='total_bill', kind='violin', col='day', row='time', height=4, aspect=0.7)
plt.subplots_adjust(top=0.9)  # Adjust the top to make room for the title
plt.suptitle('Total Bill by Sex across Days and Times', fontsize=16)
plt.show()

# FacetGrid example (axes-level function)
g = sns.FacetGrid(data=tips, col='day', row='time', height=4, aspect=0.7)
g.map(sns.violinplot, 'sex', 'total_bill')

# Set titles and labels for FacetGrid
for ax in g.axes.flat:
    ax.set_title(ax.get_title(), fontsize=12)
    ax.set_xlabel('Sex', fontsize=10)
    ax.set_ylabel('Total Bill', fontsize=10)

plt.subplots_adjust(top=0.9)  # Adjust the top to make room for the title
g.fig.suptitle('Total Bill by Sex across Days and Times', fontsize=16)
plt.show()
