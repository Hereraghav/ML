import numpy as np
import seaborn as sns
import plotly.express as px
import matplotlib.pyplot as plt

tips=sns.load_dataset('tips')

#Axes level
sns.regplot(data=tips,x='total_bill',y='tip')
plt.show()

sns.lmplot(data=tips,x='total_bill',y='tip',hue='sex')
plt.show()

#residplot - used to know error rate
sns.residplot(data=tips,x='total_bill',y='tip')
plt.show()
