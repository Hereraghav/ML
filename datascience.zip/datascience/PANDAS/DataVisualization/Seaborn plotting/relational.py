import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px

tips=sns.load_dataset('tips')

#scatterplot
#axis level function
sns.scatterplot(data=tips,x='total_bill',y='tip',hue='sex',style='time')
plt.show()

#relplot
#figure level function
sns.relplot(data=tips,  x='total_bill',y='tip',kind='scatter',hue='sex',style='time')
plt.show()

#lINEPLOT
gap=px.data.gapminder()
df=gap[gap['country']=='India']

#axis level function
sns.lineplot(data=df,x='year',y='lifeExp')
plt.show()

#using relplot
sns.relplot(data=df,x='year',y='lifeExp',kind='line')
plt.show()

#Hue-style
con=gap[gap['country'].isin(['India','Brazil','Germany'])]
sns.relplot(kind='line',data=con,x='year',y='lifeExp',hue='country',style='continent')
plt.show()

#Facet plot-2 diffrential plot of category
sns.relplot(data=tips,x='total_bill',y='tip',kind='scatter',col='smoker',row='sex')
plt.show()

#colwrap
 #used to wrap if there are too many columns colwrap=4

    