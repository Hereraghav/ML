import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
x=np.linspace(-10,10,50)
y=10*x +3+ np.random.randint(0,300,50)
plt.figure()
plt.scatter(x,y)
# plt.show()

#Data
batter=pd.read_csv('D:\\PANDAS\\datasets\\DataVisualization\\batter.csv')
df=batter.head(50)
# print(df) 
plt.figure()
plt.scatter(df['avg'],df['strike_rate'])
plt.title('AVG AND STRIKE RATE OF TOP 50')
plt.xlabel('avg')
plt.ylabel('Strike rate')
plt.show()