import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#HISTOGRAM
#Univariate analysis ,Numerical col,Frequency count

vk=pd.read_csv('datasets/DataVisualization/vk.csv')
plt.figure()
plt.hist(vk['batsman_runs'],bins=[0,10,20,30,40,50,60,70,80,90,100,120,])
plt.show()

# PIE CHART
#Univariate/Pivariate ,Categorical and numerical,Contribution
cg=pd.read_csv('D:\PANDAS\datasets\DataVisualization\gayle-175.csv')
plt.figure()
plt.pie(cg['batsman_runs'],labels=cg['batsman'],autopct='%0.1f%%',explode=[0.1,0,0,0,0,0])
#explode to focus a particular category
#shadow=True
#can also add colors
plt.show()
