#ANNOTATION is used to place text in scatterPlot
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns 

bat=pd.read_csv('datasets/DataVisualization/batter.csv')
df=bat.head(10)
plt.figure(figsize=(15,7))
plt.scatter(df['avg'],df['strike_rate'])    
for i in range(df.shape[0]):
    plt.text(df['avg'].values[i],df['strike_rate'].values[i],df['batter'].values[i])
plt.axhline(130,color='red')#horizontal Line
plt.axvline(30,color='red')# vertical line
plt.show()
