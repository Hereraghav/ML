import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
bat = pd.read_csv('datasets/DataVisualization/batter.csv')

# Select the top 20 rows
df = bat.head(20)

# 3D scatter plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(df['runs'], df['avg'], df['strike_rate'])
ax.set_title('IPL')
ax.set_xlabel('Runs')
ax.set_ylabel('Avg')
ax.set_zlabel('Strike Rate')
plt.show()

# 3D line plot
x = [0, 1, 5]
y = [0, 13, 15]
z = [0, 13, 20]
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter3D(x, y, z, s=[100, 100, 100])
ax.plot3D(x, y, z)
plt.show()

# 3D surface plot (Loss function)
x = np.linspace(-10, 10, 100)
y = np.linspace(-10, 10, 100)
xx, yy = np.meshgrid(x, y)
z = xx**2 + yy**2
fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(xx, yy, z, cmap='viridis')
plt.show()

# 3D surface plot (Sine and Cosine function
z = np.sin(xx) + np.cos(yy)
fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(111, projection='3d')
f = ax.plot_surface(xx, yy, z, cmap='viridis')
fig.colorbar(f, ax=ax, shrink=0.5, aspect=5)
plt.show()

# Contour plots - 2D representation of 3D surface plot
fig= plt.figure(figsize=(12, 8))
ax=plt.subplot()
p = ax.contourf(xx, yy, z, cmap='viridis')
fig.colorbar(p, ax=ax)
plt.show()
