import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# types of DATA - Numerical and Categorical
 
#Bivariate analysis- 2 cols
bat=pd.read_csv('D:\PANDAS\datasets\DataVisualization\sharma-kohli.csv')
plt.plot(bat['index'],bat['V Kohli'])
# plt.show()

#Multiple PLots
plt.plot(bat['index'],bat['V Kohli'])
plt.plot(bat['index'],bat['RG Sharma'])
# plt.show()

#Labels titles
plt.plot(bat['index'],bat['V Kohli'])
plt.plot(bat['index'],bat['RG Sharma'])
plt.title('RG Sharma VS Virat Kohli')
plt.xlabel('Season')
plt.ylabel('Runs')
# plt.show()

#Colors(hex) and line(width and style )and maker (size)
plt.plot(bat['index'],bat['V Kohli'],color='red',linewidth=1,marker='.',markersize=20,label='V kohli')
plt.plot(bat['index'],bat['RG Sharma'],color='blue',linestyle='dashdot',label='RG sharma')
plt.title('RG Sharma VS Virat Kohli')
plt.xlabel('Season')
plt.ylabel('Runs')
# plt.show() 

#LEGEND-> location
plt.figure()
plt.plot(bat['index'],bat['V Kohli'],color='red',linewidth=1,marker='.',markersize=20,label='V kohli')
plt.plot(bat['index'],bat['RG Sharma'],color='blue',linestyle='dashdot',label='RG sharma')
plt.title('RG Sharma VS Virat Kohli')
plt.xlabel('Season')
plt.ylabel('Runs')
plt.grid() #for readability
plt.legend(loc='best')
# plt.show() 

#Limiting axis
price=[4000,6000,8000,10000,450000]
year=[2015,2016,2017,2018,2020]
plt.figure()
plt.plot(year,price)
plt.ylim(0,50000)
# plt.xlim(2018,2020)
# plt.show()    
