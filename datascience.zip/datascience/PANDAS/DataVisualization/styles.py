import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

print(plt.style.available)
plt.style.use('fivethirtyeight')
plt.style.use('dark_background')
plt.style.use('ggplot')

#To save any chart 
# plt.savefig('ipl.png')
