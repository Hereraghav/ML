import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
bat = pd.read_csv('datasets/DataVisualization/batter.csv')

# Select the top 10 rows
df = bat.head(10)

# Create a figure and axis for the scatter plot
fig, ax = plt.subplots(figsize=(14, 6))

# Scatter plot
ax.scatter(df['avg'], df['strike_rate'], color='red', marker='o')

# Set title and labels
ax.set_title('Batsman')
ax.set_xlabel('Avg')
ax.set_ylabel('Strike Rate')

# Display the plot
plt.show()

# Subplot - multiple plots
fig, ax = plt.subplots(nrows=2, ncols=1, sharex=True)
ax[0].scatter(df['avg'], df['strike_rate'], color='red', marker='o')
ax[1].scatter(df['avg'], df['strike_rate'])
ax[0].set_title('Avg vs Strike Rate')
ax[0].set_ylabel('Strike Rate')
ax[1].set_title('Avg vs Runs')
ax[1].set_ylabel('Runs')
ax[1].set_xlabel('Avg')
plt.show()

# Multigraph
fig = plt.figure()

# Subplot 1: Scatter plot
ax1 = fig.add_subplot(2, 2, 1)  # (rows, cols, graph no)
ax1.scatter(df['avg'], df['strike_rate'], color='black')
ax1.set_title('Avg vs Strike Rate')
ax1.set_xlabel('Avg')
ax1.set_ylabel('Strike Rate')

# Subplot 2: Histogram
ax2 = fig.add_subplot(2, 2, 2)
ax2.hist(df['avg'], bins=10, color='blue', edgecolor='black')
ax2.set_title('Histogram of Avg')
ax2.set_xlabel('Avg')
ax2.set_ylabel('Frequency')

# Subplot 3: Pie chart
ax3 = fig.add_subplot(2, 2, 3)
ax3.pie(df['strike_rate'], labels=df['batter'], autopct='%1.1f%%')
ax3.set_title('Strike Rate Distribution')

plt.legend()
plt.tight_layout()
plt.show()

#Multigraph option 2 (efficient way )
fig,ax=plt.subplots(nrows=2,ncols=2,figsize=(10,10))
ax[0,0]
ax[0,1].scatter(df['avg'],df['runs'])
ax[1,0].hist(df['avg'])
ax[1,1].hist(df['runs'])
plt.show()
