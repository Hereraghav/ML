import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
ball = pd.read_csv('datasets/DataVisualization/IPL_Ball_by_Ball_2008_2022.csv')

# Filtering data for balls numbered 1 to 6 and batsman run equals 6
df = ball[(ball['ballnumber'].isin([1, 2, 3, 4, 5, 6])) & (ball['batsman_run'] == 6)]

# Create a pivot table
grid = df.pivot_table(index='overs', columns='ballnumber', values='batsman_run', aggfunc='count')

# Plotting the data
plt.figure(figsize=(16, 8))
plt.imshow(grid, aspect='auto', cmap='viridis')

# Set x-ticks
plt.xticks(np.arange(0, 6), list(range(1, 7)))

# Set y-ticks
overs_unique_sorted = sorted(df['overs'].unique())
plt.yticks(np.arange(len(overs_unique_sorted)), overs_unique_sorted)

# Add colorbar
plt.colorbar(label='Count of 6s')

# Add labels and title
plt.xlabel('Ball Number')
plt.ylabel('Over Number')
plt.title('Count of 6s per Ball Number and Over in IPL')

plt.show()
