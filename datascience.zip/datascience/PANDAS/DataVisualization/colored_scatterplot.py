import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the iris dataset
iris = pd.read_csv('D:\\PANDAS\\datasets\\DataVisualization\\iris.csv')

# Print a sample of the data
# print(iris.sample())

# Replace species names with numerical values
iris['Species'] = iris['Species'].replace({'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2})

# Plotting the scatter plot
plt.figure() 
plt.scatter(iris['SepalLengthCm'], iris['SepalWidthCm'], c=iris['Species'],cmap='winter')
#plt.figure(figsize=(15,7)) can edit size of fig chart too
#cmap= 'winter'/'summer'/'jet' - color themes
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Sepal Width (cm)')
plt.title('Sepal Length vs Sepal Width')
plt.colorbar(label='Species')
plt.show()


