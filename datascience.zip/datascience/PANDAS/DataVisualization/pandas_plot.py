import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
tips=sns.load_dataset('tips')

#scatterplot -> labels->markers->figsize->color->cmap
plt.figure()
tips.plot(kind='scatter',x='total_bill',y='tip',title='Cost analysis',c='sex',cmap='viridis',s='size',marker='+',figsize=(10,6) )
plt.show()

#   Dataset- abstraction
#  barchart
record=pd.read_csv('D:\\PANDAS\\datasets\\DataVisualization\\batsman_season_record.csv')
record.plot(kind='bar')
plt.show()
# for stacked
record.plot(kind='bar',stacked=True)
plt.show()

#Multiple graphs on pandas
record.plot(kind='line',subplots=True)
plt.show()

#ON multiindex ddf
tips.pivot_table(index=['day','time'],columns='sex',values='total_bill',aggfunc='mean').plot(kind='line',figsize=(15,8))
plt.show()
