#Data Analytics
#--Data gathering ,data cleaning ,  EDA 
#-- Import and Export

#Data Analysis Process
#- Asking Question -> Data wrangling -> Explolatory Data Analysis -> Drawing conclusion - > Communicating results
 