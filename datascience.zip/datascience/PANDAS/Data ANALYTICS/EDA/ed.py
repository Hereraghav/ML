import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv("datasets/session22/titanic.csv")

# Exploratory Data Analysis (EDA)
# --------------------------------

# Data Overview
print(df.head())

# Column types
# Numerical: Age, Fare, PassengerId
# Categorical: Survived, Pclass, Sex, SibSp, Parch, Embarked
# Mixed: Name, Ticket, Cabin

# Numerical Features Analysis
# ---------------------------

# Age
print("Age Column Description:\n", df['Age'].describe())

# Plotting Age distribution
plt.figure()
df['Age'].plot(kind='kde')
plt.title('Age Distribution')
plt.xlabel('Age')
plt.ylabel('Density')
plt.show()

# Skewness of Age
print("Age Skewness:", df['Age'].skew())

# Checking for missing values in Age
print("Missing Age Values:", df['Age'].isnull().sum()/len(df['Age']))

# Conclusion for Age
# Age is normally distributed with 20% missing values, and there are some outliers.

# Fare
print("Fare Column Description:\n", df['Fare'].describe())

# Plotting Fare distribution
plt.figure()
df['Fare'].plot(kind='kde')
plt.title('Fare Distribution')
plt.xlabel('Fare')
plt.ylabel('Density')
plt.show()

# Box plot for Fare
plt.figure()
df['Fare'].plot(kind='box')
plt.title('Fare Box Plot')
plt.show()

# Skewness of Fare
print("Fare Skewness:", df['Fare'].skew())

# Conclusion for Fare
# Highly positively skewed. The Fare column contains group fares, not individual fares, and needs further processing.

# Categorical Features Analysis
# -----------------------------

# Survived
plt.figure()
df['Survived'].value_counts().plot(kind='pie', autopct='%0.1f%%')
plt.title('Survival Rate')
plt.ylabel('')
plt.show()

# Checking for missing values in Survived
print("Missing Survived Values:", df['Survived'].isnull().sum())

# Conclusion for Survived
# No missing values. More than 50% of passengers died.

# Bivariate Analysis
# ------------------

# Survival rate by Passenger Class
print("Survival Rate by Passenger Class:\n", pd.crosstab(df['Survived'], df['Pclass'], normalize='columns') * 100)

# Survival rate by Gender
print("Survival Rate by Gender:\n", pd.crosstab(df['Survived'], df['Sex'], normalize='columns') * 100)

# Feature Engineering
# -------------------

# Handle Missing Values
# Example: Fill missing Age values with median
df['Age'].fillna(df['Age'].median(), inplace=True)

# Example: Fill missing Embarked values with mode
df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)

# Detecting Outliers
# ------------------

# Example: Identify outliers in Fare using IQR
Q1 = df['Fare'].quantile(0.25)
Q3 = df['Fare'].quantile(0.75)
IQR = Q3 - Q1
outliers = df[(df['Fare'] < (Q1 - 1.5 * IQR)) | (df['Fare'] > (Q3 + 1.5 * IQR))]

print("Number of outliers in Fare:", len(outliers))

# Example: Handling outliers - capping Fare at upper bound
upper_bound = Q3 + 1.5 * IQR
df['Fare'] = np.where(df['Fare'] > upper_bound, upper_bound, df['Fare'])

# Final processed DataFrame
print("Final DataFrame Shape:", df.shape)
print(df.head())
