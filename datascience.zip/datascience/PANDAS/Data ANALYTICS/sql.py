import pandas as pd
import mysql.connector
conn=mysql.connector.connect(host='localhost',user='root',password='',database='world')
city=pd.read_sql_query("SELECT * FROM city WHERE CountryCode LIKE 'IND'",conn)
le=pd.read_sql_query("SELECT * FROM country WHERE LifeExpectancy > 60",conn)
cl=pd.read_sql_query("SELECT * FROM countrylanguage",conn)
print(cl)