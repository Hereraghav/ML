import pandas as pd
import requests
from bs4 import BeautifulSoup
import numpy as np

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'} 
session = requests.Session()
webpage = session.get('https://www.ambitionbox.com/list-of-companies?page=1', headers=headers).text

soup = BeautifulSoup(webpage, 'html.parser')

# Debugging prints to check HTML structure
print(soup.prettify())

# Extracting company details
company = soup.find_all('div', class_='company-content-wrapper')

# Debugging print to check if companies are being found
print(f"Number of companies found: {len(company)}")

name = []
rating = []
reviews = []
ctype = []
hq = []
how_old = []
no_of_employee = []

for i in company:
    try:
        name.append(i.find('h2').text.strip())
    except:
        name.append(np.nan)

    try:
        rating.append(i.find('p', class_='rating').text.strip())
    except:
        rating.append(np.nan)

    try:
        reviews.append(i.find('a', class_='review-count').text.strip())
    except:
        reviews.append(np.nan)

    try:
        ctype.append(i.find_all('p', class_='infoEntity')[0].text.strip())
    except:
        ctype.append(np.nan)

    try:
        hq.append(i.find_all('p', class_='infoEntity')[1].text.strip())
    except:
        hq.append(np.nan)

    try:
        how_old.append(i.find_all('p', class_='infoEntity')[2].text.strip())
    except:
        how_old.append(np.nan)

    try:
        no_of_employee.append(i.find_all('p', class_='infoEntity')[3].text.strip())
    except:
        no_of_employee.append(np.nan)

df = pd.DataFrame({
    'name': name,
    'rating': rating,
    'reviews': reviews,
    'company_type': ctype,
    'Head_Quarters': hq,
    'Company_Age': how_old,
    'No_of_Employee': no_of_employee,
})

# Debugging print to check the dataframe
print(df.head())
print(df.shape)
