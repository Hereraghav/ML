import pandas as pd
import requests
from bs4 import BeautifulSoup
import numpy as np

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

webpage = requests.get('https://www.ambitionbox.com/list-of-companies?page=1', headers=headers).text

soup = BeautifulSoup(webpage, 'lxml')

# Check if the response is successful
if soup is not None:
    print("Webpage fetched successfully.")
else:
    print("Failed to fetch webpage.")

# Print a sample title to verify fetching
print("Page Title:", soup.title.text if soup.title else "No title found")

# Extracting data
company = soup.find_all('div', class_='company-content-wrapper')

name = []
rating = []
reviews = []
ctype = []
hq = []
how_old = []
no_of_employee = []

for i in company:
    try:
        name.append(i.find('h2').text.strip())
    except:
        name.append(np.nan)

    try:
        rating.append(i.find('p', class_='rating').text.strip())
    except:
        rating.append(np.nan)

    try:
        reviews.append(i.find('a', class_='review-count').text.strip())
    except:
        reviews.append(np.nan)

    try:
        ctype.append(i.find_all('p', class_='infoEntity')[0].text.strip())
    except:
        ctype.append(np.nan)

    try:
        hq.append(i.find_all('p', class_='infoEntity')[1].text.strip())
    except:
        hq.append(np.nan)

    try:
        how_old.append(i.find_all('p', class_='infoEntity')[2].text.strip())
    except:
        how_old.append(np.nan)

    try:
        no_of_employee.append(i.find_all('p', class_='infoEntity')[3].text.strip())
    except:
        no_of_employee.append(np.nan)

df = pd.DataFrame({
    'name': name,
    'rating': rating,
    'reviews': reviews,
    'company_type': ctype,
    'Head_Quarters': hq,
    'Company_Age': how_old,
    'No_of_Employee': no_of_employee,
})

print("DataFrame Shape:", df.shape)
print("Sample DataFrame:", df.sample(5))

final = pd.DataFrame()

for j in range(1, 3):  # Limiting to 3 pages for example, adjust as needed
    webpage = requests.get(f'https://www.ambitionbox.com/list-of-companies?page={j}', headers=headers).text
    soup = BeautifulSoup(webpage, 'lxml')
    company = soup.find_all('div', class_='company-content-wrapper')
    
    name = []
    rating = []
    reviews = []
    ctype = []
    hq = []
    how_old = []
    no_of_employee = []

    for i in company:
        try:
            name.append(i.find('h2').text.strip())
        except:
            name.append(np.nan)

        try:
            rating.append(i.find('p', class_='rating').text.strip())
        except:
            rating.append(np.nan)

        try:
            reviews.append(i.find('a', class_='review-count').text.strip())
        except:
            reviews.append(np.nan)

        try:
            ctype.append(i.find_all('p', class_='infoEntity')[0].text.strip())
        except:
            ctype.append(np.nan)

        try:
            hq.append(i.find_all('p', class_='infoEntity')[1].text.strip())
        except:
            hq.append(np.nan)

        try:
            how_old.append(i.find_all('p', class_='infoEntity')[2].text.strip())
        except:
            how_old.append(np.nan)

        try:
            no_of_employee.append(i.find_all('p', class_='infoEntity')[3].text.strip())
        except:
            no_of_employee.append(np.nan)

    df = pd.DataFrame({
        'name': name,
        'rating': rating,
        'reviews': reviews,
        'company_type': ctype,
        'Head_Quarters': hq,
        'Company_Age': how_old,
        'No_of_Employee': no_of_employee,
    })

    final = final.append(df, ignore_index=True)

print("Final DataFrame Shape:", final.shape)
print("Sample Final DataFrame:", final.sample(5))
