import pandas as pd
import requests
from bs4 import BeautifulSoup

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

# Send the request
response = requests.get('https://www.ambitionbox.com/list-of-companies?page=1', headers=headers)

# Check if the request was successful
if response.status_code == 200:
    print("Request successful")
    # Print the response text length
    print(f"Response Length: {len(response.text)}")
    
    # Parse the HTML content
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Print the title of the page to verify parsing
    print("Page Title:", soup.title.text)
    
    # Extracting company names
    companies = []
    for company in soup.find_all('div', class_='company-content-wrapper'):
        company_name = company.find('h2', class_='company-name').text.strip()
        companies.append(company_name)
    
    # Display extracted company names
    if companies:
        print("Extracted company names:")
        for idx, company in enumerate(companies):
            print(f"{idx + 1}. {company}")
    else:
        print("No companies found.")
else:
    print(f"Failed to retrieve the webpage. Status code: {response.status_code}")
