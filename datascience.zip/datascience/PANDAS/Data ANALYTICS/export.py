#PANDAS export to 
# to sql,csv,excel,json,html
import pandas as pd
df=pd.DataFrame()
# df.to_csv
ipl=pd.read_csv('D:\\PANDAS\\datasets\\numpy_ds\\deliveries.csv')
record=ipl.groupby('batsman')['batsman_runs'].sum().reset_index()
record.to_csv('record_ipl_batter.csv',index=False)