import pandas as pd
import numpy as np

titanic=pd.read_csv('D:\\PANDAS\\datasets\\session22\\titanic.csv')
# print(titanic.head())

#Lower/uppper/captialize/title
print('Lower:\n',titanic['Name'].str.lower().sample(1))
print("\n")
print('Title:\n',titanic['Name'].str.title().sample(1))
print("\n")
print('Upper:\n',titanic['Name'].str.upper().sample(1))
print("\n")
print('Capitalize:\n',titanic['Name'].str.capitalize().sample(1))
print("\n")

# print(titanic.info())
#Len -longest name passanger
print('Longest name in passangers:',titanic['Name'][titanic['Name'].str.len()==82].values[0])
print("\n")

#Strip-  '                  ram             ' -> 'ram'
#removes leading preding spaces
# print(titanic['Name'].str.strip())


#Split-get

#Spliting first name on MR /MRS
titanic[['title','firstname']]=titanic['Name'].str.split(',').str.get(1).str.strip().str.split(' ',n=1,expand=True)# n= how many splits u want
#expand will convert series to df in this

# To get surname of passangers from Name
titanic['lastname']=titanic['Name'].str.split(',').str.get(0)


#Now to knw how many mr and mrs were there
print('Total male /female were : \n',titanic['title'].value_counts().head(2))
print("\n")

#Replace
#str.replace('OLD','NEW')
titanic['title']=titanic['title'].str.replace('Ms.','Miss.')
titanic['title']=titanic['title'].str.replace('Mlle.','Miss.')

#Filtering
#Startswith/endswith
print('Name of passangers starts with A:\n',titanic[titanic['firstname'].str.startswith('A')])
print('\n')
print('Name of passangers ends with A:\n',titanic[titanic['lastname'].str.endswith('A')])
print('\n')
#isDigit /isalpha to know if data contains any numeric values

#applying regex
#contains
#Search john- > l/u
print('Does data has John ?:\n',titanic[titanic['Name'].str.contains('john',case=False)])
#case-false bcoz it can be upper /lower
print('\n')

#find surname which start and end with vowels.
print(" surname which start and end with vowel: \n",titanic['lastname'][titanic['lastname'].str.contains('^[aeiouAEIOU].+[aeiouAEIOU]$',na=False)])
# ^[aeiouAEIOU] matches the start of a string followed by a vowel.
# .+ matches one or more characters.
# [aeiouAEIOU]$ matches the end of a string followed by a vowel.
# na=False ensures that NA values are excluded from the filtering
print('\n')

#SLICING
#Reverse the lastnames
print('Reveresed last name:\n',titanic['lastname'].str[::-1].sample(5))