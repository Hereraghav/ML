import pandas as pd
import numpy as np


#MultiIndexing  series(also known as heirarchical indexing )
#How to create multiindex object
#1) using .multiindex.from_tuples
index_val=[('cse',2019),('cse',2020),('cse',2021),('cse',2022),('ece',2019),('ece',2020),('ece',2021),('ece',2022)]
multiindex=pd.MultiIndex.from_tuples(index_val)
print(multiindex.levels) #decoupled indexes
print("\n")
#2) using multiindex.from_products
print(pd.MultiIndex.from_product([['cse','ece'],[2019,2020,2021,2022]])) #using cartisen product
print("\n")

#Creating a series with mutliindex
s=pd.Series([1,2,3,4,5,6,7,8],index=multiindex)
print("Series using multiindex:\n",s)
print("\n")

#Fetch item from series
print(s['cse'])
print("\n")

#unstack -convert multiindex series to dataframe
print(s.unstack())
print("\n")

#stack()-convert dataframe to mi series
# print(s.stack())
# print("\n")


#MULTIINDEX DATAFRAME
branch_Df1=pd.DataFrame(
    [
        [1,2],
        [3,4],
        [5,6],
        [7,8],
        [9,10],
        [11,12],
        [13,14],
        [15,16],
        ],index=multiindex,columns=['lpa','student']

)
print(branch_Df1)
print('\n')

#Multindex in terms of both cols and index
branch_df2=pd.DataFrame(
    [
        [1,2,3,4],
        [5,6,7,8],
        [9,10,11,12],
        [1,2,3,4],
        [5,6,7,8],
        [9,10,11,12],
        [1,2,3,4],
        [5,6,7,8],
        
    ],index=multiindex,columns=pd.MultiIndex.from_product([['delhi','Mumbai'],['lpa','students']])
)
print("Multilevel index in terms of cols and row :\n",branch_df2)
print('\n ')

#Stacking and Unstacking
#unstack is row will become column
#stack is col will become row

#on 3d df
print("unstacking on DF1:\n",branch_Df1.unstack())
print("\n")
print("Stacking on df1:\n",branch_Df1.stack())
print("\n")

#On 4d df 
print("unstacking on DF2:\n",branch_df2.unstack())
print("\n")
print("Stacking on df2:\n",branch_df2.stack())
print("\n")

#Some basic functions on 3d multiindex

print(branch_df2.head())
print(branch_df2.tail())
print(branch_df2.shape)
print(branch_df2.info())
print("\n")

#extracting rows single.
print(branch_df2.loc[('cse',2022)])
#extracting multiple rows
print(branch_df2.loc[('cse',2019):('ece',2020):2])
#or
# print(branch_df2.iloc[0:5:2])
print("\n")

#extracting cols
print(branch_df2['delhi']['students'])
print("\n")
print(branch_df2.iloc[:,1:3])
print("\n")
#fancy indexing
print(branch_df2.iloc[[0,4],[1,2]])
print("\n")

#Sort index
#both -> descending -> diff order
#based on one level
print("Year WISE SORTING :\n",branch_df2.sort_index(level=1,ascending=False))
print("\n")

#Transpose- switch row and col
print("Transpose:\n",branch_df2.transpose())
print("\n")

#swaplevel -index swaping
print("Swapping:\n",branch_df2.swaplevel())
#on col; swaplevel (axis=1)
print("\n")

