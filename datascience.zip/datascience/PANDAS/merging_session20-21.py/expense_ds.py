#PLotting with pivot
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt 

ed=pd.read_csv('D:\PANDAS\datasets\session22\expense_data.csv')
# print(ed.head())

# print(ed['Category'].value_counts())

#Converting (String) date to datetime
ed['Date']=pd.to_datetime(ed['Date']) 
# print(ed.info()) #Date changed frm object to datetime dtype

ed['Month']=ed['Date'].dt.month_name()
#created new col month

#Plotting
print(ed.pivot_table(index='Month',columns='Category',values='INR',aggfunc='sum',fill_value=0).plot())#
#fill value=0  convert nan values to 0
plt.show()
print('\n')

#Datetime functions
print(ed['Date'].dt.month_name().sample(2))
print(ed['Date'].dt.is_month_start.value_counts())#is_quater_start/end

#day wise bar chart
ed['day_name']=ed['Date'].dt.day_name()
print(ed.groupby('day_name')['INR'].sum().sort_values(ascending=False).plot(kind='bar'))
plt.show()

