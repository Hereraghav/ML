import pandas as pd
import numpy as np


#melt -used to convert wide data format to long data format
print(pd.DataFrame({'cse':[120],"ece":[100],'mech':[80]}))
print("\n")
print("Melt form data frame :\n",pd.DataFrame({'cse':[120],"ece":[100],'mech':[80]}).melt(var_name='Branch',value_name='Students')) 
print('\n')

#Using with a dictionary
print(pd.DataFrame({
    'branch':['cse','ece','mech'],
    '2020':[100,70,80],
    '2021':[80,90,100],
    '2022':[100,90,80],
}))
print('\n')
#as i dont want branch to get converted
print(pd.DataFrame({
    'branch':['cse','ece','mech'],
    '2020':[100,70,80],
    '2021':[80,90,100],
    '2022':[100,90,80],
}).melt(id_vars=['branch'],var_name='year',value_name='students')   )
print('\n')
print('***********************************************************************************************************')


data=pd.read_csv('D:\\PANDAS\\datasets\\session20\\time_series_covid19_deaths_global.csv')
confirm=pd.read_csv('D:\\PANDAS\\datasets\\session20\\time_series_covid19_confirmed_global.csv')

death=data.melt(id_vars=['Province/State','Country/Region','Lat','Long'],var_name='date',value_name='num_Death')
con=data.melt(id_vars=['Province/State','Country/Region','Lat','Long'],var_name='date',value_name='num_cases')

print(con.merge(death,on=['Province/State','Country/Region','Lat','Long','date'])[['Country/Region','date','num_cases','num_Death']].sample())


