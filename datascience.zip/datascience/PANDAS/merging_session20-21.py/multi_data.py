import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Reading CSV files
course = pd.read_csv("D:\\PANDAS\\datasets\\session20\\courses.csv")
student = pd.read_csv("D:\\PANDAS\\datasets\\session20\\students.csv")
nov = pd.read_csv('D:\\PANDAS\\datasets\\session20\\reg-month1.csv')
dec = pd.read_csv('D:\\PANDAS\\datasets\\session20\\reg-month2.csv')

#pd.concat- vertical stack
month=pd.concat([nov,dec],ignore_index=True ) #To overcome the index 01-31,01-30 will be 1-51

#multiindex dataframe
#mutli = pd.concat([nov,dec],keys=['Nov','dec']) nov and dec will be 2 indexes
#to extract data index wise # 

# multi.loc['dec'] # will list dec df
#to get detail/values in multiindex
#multi.loc[('dec',1)] 


# #pd.concat-horizontal stack
# pd.concat([nov,dec],axis=1)

#inner join
print("Inner Join:\n",student.merge(month,how='inner',on='student_id'))
print('\n')

#left join
print('Left join:\n',course.merge(month,how='left',on='course_id'))
print("\n")

#right join
print('Righ join:\n',student.merge(month,how='right',on='student_id'))
print("\n")

#outer join
print("Outer join:\n",student.merge(month,how='outer',on='student_id'))
print("\n")

#find total revenue generated
print("Total revenue generated :Rs",month.merge(course,how='inner',on="course_id")['price'].sum())

#Find month by month revenues
temp=pd.concat([nov,dec],keys=['Nov','dec']).reset_index()
print("\n ",temp.merge(course,on='course_id').groupby('level_0')['price'].sum())
print("\n")

#print regis table (cols-name-course-price)
print("Registration Table:\n",month.merge(student,on='student_id').merge(course,on='course_id')[['name','course_name','price']])
print('\n')

#plot bar chart for revenue in each course
print(month.merge(course,on='course_id').groupby("course_name")['price'].sum().plot(kind='bar'))
# plt.show()
print("\n")


#find student enrolled in both month
common_student=np.intersect1d(nov['student_id'],dec['student_id'])
print("Student enrolled in both months:\n",student[student['student_id'].isin(common_student)])
print("\n")

#find courses with no enrolls
no_enroll=np.setdiff1d(course['course_id'],month['course_id'])
print('Courses with no enrollments:\n',course[course['course_id'].isin(no_enroll)])
print('\n')

#find students who didnt enroll in any course
student_notenroll=np.setdiff1d(student['student_id'],month['student_id'])
print("Student who didnt enrolled in any course: \n",student[student['student_id'].isin(student_notenroll)])
print('\n')

#Print student nd partner name for enrolled courses
print("student nd partner name for enrolled courses:\n",student.merge(student,how='inner',left_on='partner',right_on='student_id')[['name_x','name_y']])
print('\n')
#Top 3 student with most enrolls
print("Most enrollments:\n",month.merge(student,on='student_id').groupby(['student_id','name'])['name'].count().sort_values(ascending=False).head(3))
print('\n')

#Top student who paid
print("Student who paid most:\n",month.merge(student,on='student_id').merge(course,on='course_id').groupby(['student_id','name'])['price'].sum().sort_values(ascending=False).head(3))

#Alternate merge syntax
#print(pd.merge(student,course,how='inner',on='student_id'))