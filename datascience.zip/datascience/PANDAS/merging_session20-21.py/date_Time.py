import pandas as pd
import numpy as np

#Vectorized date.time based functions
#Creating TimeStamp Objects:
x=pd.Timestamp('2024-07-27 5:40PM')

#pd.timestamp is of pandas
#import datetime as dt
#dt.datetime is of python
print(x)
#Fetching attrb
print('Month: ',x.month)
print('Year:',x.year)
print('day:',x.day)
print('Minute:',x.minute)
print('\n')

#Why seperate obj to handle date/time when python already has datetime functionality?
#  Syntax wise datetime is very convinient but performance takes hit when working with huge data
#this weakness inspired numpy team to add native time series date type.
#the datetime64 dtype encodes dates as 64b int , thus allow array of dates to be represented very compactly
#biggest advantage is it can support Vectorized ops


#timestamp= used for storing single obj
#Datetime index object- used to store multiple objects
#From string
data=pd.DatetimeIndex(['2023-1-1','2022-1-1','2021-1-1'])
print(pd.Series([1,2,3],index=data))
# can make series as well as df
print('\n')

#Date_range functions
#Generate daily dates in given range
print(pd.date_range(start='2024/1/5',end='2024/1/31',freq='D')) #d for each day, alternate days =2D
print('\n')

#Generate business days ->B (Mon-fri)
print(pd.date_range(start='2024/1/5',end='2024/1/31',freq='B'))
print('\n')

#Generate one day per week -> W
print(pd.date_range(start='2024/1/5',end='2024/1/31',freq='W')) #w-mon for mondays , (w-thu ,w-fri)
#by default it will be sundays
print("\n")

#Hourly data
print(pd.date_range(start='2024/1/5',end='2024/1/31',freq='12H')) #can write hours diff 5h,6h,10h
print('\n')

#Month end->M
print(pd.date_range(start='2024/1/5',end='2024/1/31',freq='M'))
#month start -MS
print('\n')
#Year end -> A  
#Year start -> AS

#Period(No of results)
print(pd.date_range(start='2024/1/5',periods=25,freq='D')) #will show next 25 days
print('\n')     

#To_Datetime function ; converting object to datetime
d=pd.Series(['2023-1-1','2022-1-1','2021-1-1'])
print(pd.to_datetime(d).dt.month)
print(pd.to_datetime(d).dt.day_name())
print('\n')

#How to deal with errors
e=pd.Series(['2023-1-1','2022-101-1','2021-1-1']) #101 is error
print(pd.to_datetime(e,errors='coerce').dt.day_of_year) #coerce is used to ignore error
