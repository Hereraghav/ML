#Textual data Analysis
import pandas as pd
import numpy as np

#Vectorized ops- operation which runs on each element of an Array
a=pd.array([2,3,4])
print(a*4) # 4,12,16
print('\n')
#Searching str in pandas
s=pd.Series(['cat','bat','mat','rat','car'])
#string accessor
print('items starting with c:\n',s[s.str.startswith('c')])
print('\n')



