import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

matches = pd.read_csv('D:\\PANDAS\\datasets\\session20\\matches.csv')
delivery = pd.read_csv("D:\\PANDAS\\datasets\\session20\\deliveries.csv")
# print(matches.info())

#find top 3 six hitting stadium
temp=delivery.merge(matches,left_on='match_id',right_on='id')


most_six=temp[temp['batsman_runs']==6]
num_six= most_six.groupby("venue")['venue'].count()
#stadium ->six
num_match=matches['venue'].value_counts()
print((num_six/num_match).sort_values(ascending=False).head(3))

#find orange cap of each season
print('Orange cap winner:\n',temp.groupby(['season','batsman'])['batsman_runs'].sum().reset_index().sort_values('batsman_runs',ascending=False).drop_duplicates(subset=['season'],keep='first').sort_values('season'))
