import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt 
df=sns.load_dataset('tips') #seaborn has various built in toy datasets 
#tips is inbuilt restrauant data in seaborn

#to find Non smoker m/f bills and smoker m/f bills
#using group by
print("Using Groupby:\n",df.groupby(['sex','smoker'])[['total_bill']].mean().unstack())
print('\n')
#Now by using PIVOT Table
print('USING PIVOT TABLE:\n',df.pivot_table(index='sex',columns='smoker',values='total_bill',aggfunc='median'))
#it prints default mean, to get diff thing, we can use agg function 
print('\n') 

#Multidimensional 
print('Multidimensional pivot analysis:\n',df.pivot_table(index=['sex','smoker'],columns=['day','time'],values='total_bill'))
#We did 5d analysis
#we can also  get diff analysis :
#(,aggfunc='size':'mean','tip':'max','total_bill':"std") like this
print('\n')

#Margins-Used to do sum of row and cols(total)
print("margins:\n",df.pivot_table(index='sex',columns='smoker',values='total_bill',aggfunc='sum',margins=True))


 