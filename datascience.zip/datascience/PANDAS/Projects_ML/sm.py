import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, precision_score
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from wordcloud import WordCloud
from collections import Counter
import pickle
import string

# Download NLTK data
nltk.download('punkt')
nltk.download('stopwords')

# Initialize WordCloud and PorterStemmer
wc = WordCloud(width=500, height=500, min_font_size=10, background_color='black')
ps = PorterStemmer()

# Load dataset
df = pd.read_csv('D:\\PANDAS\\Projects_ML\\spam.csv', encoding='ISO-8859-1')

# Data cleaning
df.drop(columns=['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4'], inplace=True)
df.rename(columns={'v1': 'target', 'v2': 'text'}, inplace=True)

# Encode ham/spam
encoder = LabelEncoder()
df['target'] = encoder.fit_transform(df['target'])

# Remove duplicate rows
df = df.drop_duplicates(keep='first')

# Additional features
df['num_chars'] = df['text'].apply(len)
df['num_words'] = df['text'].apply(lambda x: len(nltk.word_tokenize(x)))
df['num_sent'] = df['text'].apply(lambda x: len(nltk.sent_tokenize(x)))

# Data preprocessing function
def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)
    text = [i for i in text if i.isalnum()]
    text = [i for i in text if i not in stopwords.words('english') and i not in string.punctuation]
    text = [ps.stem(i) for i in text]
    return ' '.join(text)

# Apply text transformation
df['transformed_text'] = df['text'].apply(transform_text)

# Handle NaN or empty entries
df['transformed_text'].replace('', np.nan, inplace=True)
df.dropna(subset=['transformed_text'], inplace=True)

# Word Clouds for Spam and Ham
spam_wc = wc.generate(df[df['target'] == 1]['transformed_text'].str.cat(sep=" "))
ham_wc = wc.generate(df[df['target'] == 0]['transformed_text'].str.cat(sep=" "))
plt.figure()
plt.imshow(spam_wc, interpolation='bilinear')
plt.axis('off')
plt.show()

plt.figure()
plt.imshow(ham_wc, interpolation='bilinear')
plt.axis('off')
plt.show()

# Prepare data for model training using TfidfVectorizer
tfidf = TfidfVectorizer(max_features=3000)
X = tfidf.fit_transform(df['transformed_text']).toarray()
y = df['target'].values

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)

# Classifier comparison
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier, ExtraTreesClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier

svc = SVC(kernel='sigmoid', gamma=1.0)
knc = KNeighborsClassifier()
mnb = MultinomialNB()
dtc = DecisionTreeClassifier()
lrc = LogisticRegression(solver='liblinear', penalty='l1')
rfc = RandomForestClassifier(n_estimators=50, random_state=2)
abc = AdaBoostClassifier(n_estimators=50, random_state=2)
bc = BaggingClassifier(n_estimators=50, random_state=2)
etc = ExtraTreesClassifier(n_estimators=50, random_state=2)
gbdt = GradientBoostingClassifier(n_estimators=50, random_state=2)
xgb = XGBClassifier(n_estimators=50, random_state=2)

clfs = {
    'SVC': svc,
    'KNeighbors': knc,
    'MultinomialNB': mnb,
    'DecisionTree': dtc,
    'LogisticRegression': lrc,
    'RandomForest': rfc,
    'AdaBoost': abc,
    'BaggingClassifier': bc,
    'ExtraTrees': etc,
    'GradientBoosting': gbdt,
    'XGBoost': xgb
}

# Model evaluation function
def train_classifier(clf, X_train, y_train, X_test, y_test):
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    return accuracy, precision

# Initialize lists to store performance metrics
accuracy_scores = []
precision_scores = []

# Evaluate multiple classifiers
for name, clf in clfs.items():
    print(f"Evaluating {name}...")
    acc, prec = train_classifier(clf, X_train, y_train, X_test, y_test)
    accuracy_scores.append(acc)
    precision_scores.append(prec)
    print(f"Accuracy: {acc}")
    print(f"Precision: {prec}")

# Create performance DataFrame
performance_df = pd.DataFrame({
    'Algorithm': clfs.keys(),
    'Accuracy': accuracy_scores,
    'Precision': precision_scores
}).sort_values('Precision', ascending=False)

# Display performance comparison
print('\nPerformance Comparison:')
print(performance_df)

# Select the best model based on highest precision (and accuracy as a secondary criterion)
best_model_index = performance_df['Precision'].idxmax()
best_model_name = performance_df.iloc[best_model_index]['Algorithm']
best_model = clfs[best_model_name]

# Train the best model on the entire dataset and save it using pickle
best_model.fit(X_train, y_train)

# Save the vectorizer and the best model
pickle.dump(tfidf, open('vectorizer.pkl', 'wb'))
pickle.dump(best_model, open('best_model.pkl', 'wb'))

print(f"\nBest model is: {best_model_name}")
print(f"Model saved as 'best_model.pkl' and vectorizer saved as 'vectorizer.pkl'.")
