import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
import nltk
from nltk.corpus import stopwords
import string
from nltk.stem.porter import PorterStemmer
from wordcloud import WordCloud
from collections import Counter  
import seaborn as sns

wc = WordCloud(width=500, height=500, min_font_size=10, background_color='black')

ps = PorterStemmer()

# Download the required nltk data
nltk.download('punkt')
nltk.download('stopwords')

# Load dataset
df = pd.read_csv('D:\\PANDAS\\Projects_ML\\spam.csv', encoding='ISO-8859-1')

# Data cleaning: Dropping unnecessary columns
df.drop(columns=['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4'], inplace=True)

# Renaming columns for clarity
df.rename(columns={'v1': 'target', 'v2': 'text'}, inplace=True)

# Encode target labels (ham/spam -> 0/1)
encoder = LabelEncoder()
df['target'] = encoder.fit_transform(df['target'])

# Checking for missing or duplicate values
df.drop_duplicates(keep='first', inplace=True)

# Feature engineering
df['num_chars'] = df['text'].apply(len)
df['num_words'] = df['text'].apply(lambda x: len(nltk.word_tokenize(x)))
df['num_sent'] = df['text'].apply(lambda x: len(nltk.sent_tokenize(x)))

# Text preprocessing: Lowercase, tokenization, removing special chars, stopwords, punctuation, and stemming
def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)
    text = [word for word in text if word.isalnum()]
    text = [word for word in text if word not in stopwords.words('english') and word not in string.punctuation]
    text = [ps.stem(word) for word in text]
    return ' '.join(text)

df['transformed_text'] = df['text'].apply(transform_text)

# Word Clouds for Spam and Ham
plt.figure()
spam_wc = wc.generate(df[df['target'] == 1]['transformed_text'].str.cat(sep=" "))
plt.imshow(spam_wc, interpolation='bilinear')
plt.axis('off')
plt.show()

plt.figure()
ham_wc = wc.generate(df[df['target'] == 0]['transformed_text'].str.cat(sep=" "))
plt.imshow(ham_wc, interpolation='bilinear')
plt.axis('off')
plt.show()

# Word frequency analysis
def plot_word_frequencies(corpus, title):
    word_counts = Counter(corpus)
    most_common_words = word_counts.most_common(30)
    df_word_counts = pd.DataFrame(most_common_words, columns=['word', 'count'])
    plt.figure()
    sns.barplot(x='word', y='count', data=df_word_counts)
    plt.title(title)
    plt.xticks(rotation='vertical')
    plt.show()

spam_corpus = [word for msg in df[df['target'] == 1]['transformed_text'] for word in msg.split()]
ham_corpus = [word for msg in df[df['target'] == 0]['transformed_text'] for word in msg.split()]

plot_word_frequencies(spam_corpus, 'Top 30 Words in Spam Messages')
plot_word_frequencies(ham_corpus, 'Top 30 Words in Ham Messages')

# Prepare data for model training using TfidfVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
tfidf = TfidfVectorizer(max_features=3000)

X = tfidf.fit_transform(df['transformed_text']).toarray()
y = df['target'].values

# Split data into training and testing sets
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)

# Model comparison
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier, ExtraTreesClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.naive_bayes import MultinomialNB

# Initialize classifiers
clfs = {
    'SVC': SVC(kernel='sigmoid', gamma=1.0),
    'KNeighbors': KNeighborsClassifier(),
    'MultinomialNB': MultinomialNB(),
    'DecisionTree': DecisionTreeClassifier(),
    'LogisticRegression': LogisticRegression(solver='liblinear', penalty='l1'),
    'RandomForest': RandomForestClassifier(n_estimators=50, random_state=2),
    'AdaBoost': AdaBoostClassifier(n_estimators=50, random_state=2),
    'BaggingClassifier': BaggingClassifier(n_estimators=50, random_state=2),
    'ExtraTrees': ExtraTreesClassifier(n_estimators=50, random_state=2),
    'GradientBoosting': GradientBoostingClassifier(n_estimators=50, random_state=2),
    'XGBoost': XGBClassifier(n_estimators=50, random_state=2)
}

# Function to train classifier and evaluate its performance
from sklearn.metrics import accuracy_score, precision_score

def train_classifier(clf, X_train, y_train, X_test, y_test):
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    return accuracy, precision

# Evaluate each classifier
accuracy_scores = []
precision_scores = []

for name, clf in clfs.items():
    print(f"Evaluating {name}...")
    acc, prec = train_classifier(clf, X_train, y_train, X_test, y_test)
    accuracy_scores.append(acc)
    precision_scores.append(prec)
    print(f"Accuracy: {acc}")
    print(f"Precision: {prec}")

# Create a DataFrame to compare performance
performance_df = pd.DataFrame({
    'Algorithm': clfs.keys(),
    'Accuracy': accuracy_scores,
    'Precision': precision_scores
}).sort_values('Precision', ascending=False)

print('\nPerformance Comparison:')
print(performance_df)

# Select the best model based on highest precision
best_model_index = performance_df['Precision'].idxmax()
best_model_name = performance_df.iloc[best_model_index]['Algorithm']
best_model = clfs[best_model_name]

# Train the best model on the entire dataset
best_model.fit(X_train, y_train)

# Save the vectorizer and the best model using pickle
import pickle
pickle.dump(tfidf, open('vectorizer.pkl', 'wb'))
pickle.dump(best_model, open('best_model.pkl', 'wb'))

print(f"\nBest model is: {best_model_name}")
print(f"Model saved as 'best_model.pkl' and vectorizer saved as 'vectorizer.pkl'.")
