import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
import nltk
from nltk.corpus import stopwords
import string
from nltk.stem.porter import PorterStemmer
from wordcloud import WordCloud
from collections import Counter  
import seaborn as sns

wc=WordCloud(width=500,height=500,min_font_size=10,background_color='black')

ps=PorterStemmer()


# Download the punkt tokenizer
nltk.download('punkt_tab')
nltk.download('stopwords')

# Add the correct NLTK data path
nltk.data.path.append('C:/Users/ragha/AppData/Roaming/nltk_data')

df = pd.read_csv('D:\\PANDAS\\Projects_ML\\spam.csv', encoding='ISO-8859-1')
print(df.shape)

# Data cleaning
# Dropping last 3 cols as they have many null values
df.drop(columns=['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4'], inplace=True)

# Renaming first two columns
df.rename(columns={'v1': 'target', 'v2': 'text'}, inplace=True)

# Replace ham/spam with 1/0
encoder = LabelEncoder()
df['target'] = encoder.fit_transform(df['target'])

# Checking missing values
print(df.isnull().sum())
# print(nltk.data.path)

# Checking for duplicate values
print(df.duplicated().sum())

# Remove duplicate rows
df = df.drop_duplicates(keep='first')

# EDA (Exploratory Data Analysis)
plt.pie(df['target'].value_counts(), labels=['ham', 'spam'], autopct='%0.2f')
plt.legend()
plt.show()  # Data is imbalanced

# Create additional features
df['num_chars'] = df['text'].apply(len)

# Number of words
df['num_words'] = df['text'].apply(lambda x: len(nltk.word_tokenize(x)))

# Number of sentences
df['num_sent'] = df['text'].apply(lambda x: len(nltk.sent_tokenize(x)))

# Overview analysis of ham (0)
print(df[df['target'] == 0][['num_chars', 'num_words', 'num_sent']].describe())
#Overview of spam(1)
print(df[df['target'] == 1][['num_chars', 'num_words', 'num_sent']].describe())

#Data Preprocessing
#Lowercase,tokenization,removing special chars,removing stop words and punctuation,stemming
def transform_text(text):
    text=text.lower()
    text=nltk.word_tokenize(text)
    y=[]
    for i in text: 
        if i.isalnum():
            y.append(i)

    text=y[:]
    y.clear()
    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)
    
    text=y[:]
    y.clear()
    for i in text:
        y.append(ps.stem(i))

    return ' '.join(y)

# print(transform_text('Hello ,I loved the projects on Machine Learning'))

df['transformed_text']=df['text'].apply(transform_text)

plt.figure()
spam_wc = wc.generate(df[df['target'] == 1]['transformed_text'].str.cat(sep=" "))
plt.imshow(spam_wc, interpolation='bilinear')
plt.axis('off')  # Hide axes
plt.show()
# print('success wc')
plt.figure()
ham_wc = wc.generate(df[df['target'] == 0]['transformed_text'].str.cat(sep=" "))
plt.imshow(ham_wc, interpolation='bilinear')
plt.axis('off')  # Hide axes
plt.show()

# Function to plot word frequencies
def plot_word_frequencies(corpus, title):
    word_counts = Counter(corpus)
    most_common_words = word_counts.most_common(30)
    df_word_counts = pd.DataFrame(most_common_words, columns=['word', 'count'])
    plt.figure()
    sns.barplot(x='word', y='count', data=df_word_counts)
    plt.title(title)
    plt.xticks(rotation='vertical')
    plt.show()

# Create word lists for spam and ham messages
spam_corpus = [word for msg in df[df['target'] == 1]['transformed_text'] for word in msg.split()]
ham_corpus = [word for msg in df[df['target'] == 0]['transformed_text'] for word in msg.split()]

# Plot word frequencies
plot_word_frequencies(spam_corpus, 'Top 30 Words in Spam Messages')
plot_word_frequencies(ham_corpus, 'Top 30 Words in Ham Messages')



#MODEL BUILDING
#NAIVE BAYES MODEL
from sklearn.feature_extraction.text import CountVectorizer,TfidfTransformer,TfidfVectorizer
cv=CountVectorizer()
tfid=TfidfTransformer()
tfidf=TfidfVectorizer(max_features=3000)

#cv
X=cv.fit_transform(df['transformed_text']).toarray()
y=df['target'].values

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,train_size=0.2,random_state=2)

from sklearn.naive_bayes import GaussianNB,MultinomialNB,BernoulliNB
from sklearn.metrics import accuracy_score,confusion_matrix,precision_score

gnb=GaussianNB()
mnb=MultinomialNB()
bnb=BernoulliNB()

gnb.fit(X_train,y_train)
y_pred1=gnb.predict(X_test)
print("The accuracy score is : ",accuracy_score(y_test,y_pred1))
print('The confusion matrix is :',confusion_matrix(y_test,y_pred1))
print('The precision score is :', precision_score(y_test,y_pred1))

mnb.fit(X_train,y_train)
y_pred2=mnb.predict(X_test)
print("The accuracy score is : ",accuracy_score(y_test,y_pred2))
print('The confusion matrix is :',confusion_matrix(y_test,y_pred2))
print('The precision score is :', precision_score(y_test,y_pred2))

bnb.fit(X_train,y_train)
y_pred3=bnb.predict(X_test)
print("The accuracy score is : ",accuracy_score(y_test,y_pred3))
print('The confusion matrix is :',confusion_matrix(y_test,y_pred3))
print('The precision score is :', precision_score(y_test,y_pred3))

#tfid
x=tfid.fit_transform(df['transformed_text']).toarray()
y=df['target'].values

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(x,y,train_size=0.2,random_state=2)

from sklearn.naive_bayes import GaussianNB,MultinomialNB,BernoulliNB
from sklearn.metrics import accuracy_score,confusion_matrix,precision_score

gnb=GaussianNB()
mnb=MultinomialNB()
bnb=BernoulliNB()

gnb.fit(X_train,y_train)
y_pred1=gnb.predict(X_test)
print("The accuracy score is : ",accuracy_score(y_test,y_pred1))
print('The confusion matrix is :',confusion_matrix(y_test,y_pred1))
print('The precision score is :', precision_score(y_test,y_pred1))

mnb.fit(X_train,y_train)
y_pred2=mnb.predict(X_test)
print("The accuracy score is : ",accuracy_score(y_test,y_pred2))
print('The confusion matrix is :',confusion_matrix(y_test,y_pred2))
print('The precision score is :', precision_score(y_test,y_pred2))

bnb.fit(X_train,y_train)
y_pred3=bnb.predict(X_test)
print("The accuracy score is : ",accuracy_score(y_test,y_pred3))
print('The confusion matrix is :',confusion_matrix(y_test,y_pred3))
print('The precision score is :', precision_score(y_test,y_pred3))

#tfid --> MNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier

svc=SVC(kernel='sigmoid',gamma=1.0)
knc=KNeighborsClassifier()
mnb=MultinomialNB()
dtc=DecisionTreeClassifier()
lrc=LogisticRegression(solver='liblinear',penalty='l1')
rfc=RandomForestClassifier(n_estimators=50,random_state=2)
abc=AdaBoostClassifier(n_estimator=50,random_state=2)
bc=BaggingClassifier(n_estimator=50,random_state=2)
etc=ExtraTreesClassifier(n_estimator=50,random_state=2)
gbdt=GradientBoostingClassifier(n_estimator=50,random_state=2)
xgb=XGBClassifier(n_estimator=50,random_state=2)

clfs={
    'SVC':svc,
    'KN':knc,
    'NB':mnb,
    'DT':dtc,
    'LR':lrc,
    'RF':rfc,
    'AdaBoost':abc,
    'BgC':bc,
    'ETC':etc,
    'GBDT':gbdt,
    'xgb':xgb
}

def train_classifier(clf,X_train,y_train,X_test,y_test):
    clf.fit(X_train,y_train)
    y_pred=clf.predict(X_test)
    accuracy=accuracy_score(y_test,y_pred)
    precision=precision_score(y_test,y_pred)
    return accuracy,precision

print(train_classifier(svc,X_train,y_train,X_test,y_test))
accuracy_scores=[]
precision_scores=[]
for name ,clf in clfs.items():
    current_accuracy,current_precision=train_classifier(clf,X_train,y_train,X_test,y_test)
    print("For",name)
    print('Accuracy- ',current_accuracy)
    print('Precision-',current_precision)

performance_df=pd.DataFrame({'Algorithm':clfs.keys(),'Accuracy':accuracy_scores,'Precision':precision_scores}).sort_values('Precision',ascending=False)
print('\n')
print(performance_df)

performance_df1=pd.melt(performance_df,id_vars='Algorithm')
print(performance_df1)


#Model improve
#Change max features parameter of Tfidf

import pickle
pickle.dump(tfidf,open('vectorizer.pkl','wb'))
pickle.dump(mnb,open('model.pkl','wb'))