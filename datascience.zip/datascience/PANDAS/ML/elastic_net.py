from sklearn.datasets import load_diabetes
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

# Load diabetes dataset
x, y = load_diabetes(return_X_y=True)

# Split dataset into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=2)

# Linear Regression
reg = LinearRegression()
reg.fit(x_train, y_train)
y_pred = reg.predict(x_test)
print("Linear Regression R²:", r2_score(y_test, y_pred))

# Ridge Regression
rid = Ridge(alpha=0.1)  # Fixed this line
rid.fit(x_train, y_train)
y_pred = rid.predict(x_test)
print("Ridge Regression R²:", r2_score(y_test, y_pred))

# Lasso Regression
la = Lasso(alpha=0.01)
la.fit(x_train, y_train)
y_pred = la.predict(x_test)
print("Lasso Regression R²:", r2_score(y_test, y_pred))

# ElasticNet Regression
en = ElasticNet(alpha=0.005, l1_ratio=0.9)
en.fit(x_train, y_train)
y_pred = en.predict(x_test)
print("ElasticNet Regression R²:", r2_score(y_test, y_pred))
