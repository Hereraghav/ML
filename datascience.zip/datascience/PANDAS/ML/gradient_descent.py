import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import make_regression

# Generate data
x, y = make_regression(n_samples=100, n_features=1, n_informative=1, n_targets=1, noise=20)
plt.scatter(x, y)
plt.show()

# Train with sklearn's LinearRegression
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(x, y)
print("Sklearn Linear Regression Coefficient:", lr.coef_)
print("Sklearn Linear Regression Intercept:", lr.intercept_)

# Custom Gradient Descent Regressor
class GDregressor:
    def __init__(self, learning_rate, epochs):
        self.m = 0  # Initial slope
        self.b = 0  # Initial intercept
        self.lr = learning_rate
        self.epochs = epochs

    def fit(self, x, y):
        n = len(x)
        for i in range(self.epochs):
            y_pred = self.m * x.ravel() + self.b
            # Compute gradients
            dm = (-2/n) * np.sum(x.ravel() * (y - y_pred))
            db = (-2/n) * np.sum(y - y_pred)
            # Update parameters
            self.m -= self.lr * dm
            self.b -= self.lr * db
            
            # Optional: Print loss to monitor training
            loss = np.mean((y - y_pred) ** 2)
            if i % 10 == 0:
                print(f"Epoch {i+1}/{self.epochs} - Loss: {loss:.4f} - m: {self.m:.4f}, b: {self.b:.4f}")

        print(f"Final m: {self.m}, Final b: {self.b}")

# Instantiate and train the custom GD regressor
gd = GDregressor(learning_rate=0.01, epochs=1000)
gd.fit(x, y)

# Visualize the results
plt.scatter(x, y, color='blue')
plt.plot(x, gd.m * x + gd.b, color='red')  # Plot the regression line from GD
plt.xlabel('Feature')
plt.ylabel('Target')
plt.title('Gradient Descent Linear Regression')
plt.show()
