import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Set a random seed for reproducibility
np.random.seed(42)

# Generate 200 random CGPA values between 4.0 and 9.0, rounded to 1 decimal place
cgpa = np.round(np.random.uniform(4.0, 9.0, 200), 1)

# Generate a linear relationship with some noise, and round to 1 decimal place
package = np.round(2 * cgpa + np.random.normal(0, 1.5, 200), 1)

# Create the DataFrame
df = pd.DataFrame({
    'CGPA': cgpa,
    'Package': package
})

# Define X (features) and y (target)
X = df[['CGPA']]  # Features need to be a 2D array, so we use double brackets
y = df['Package']  # Target variable

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)

# Create and train the linear regression model
lr = LinearRegression()
lr.fit(X_train, y_train)

# Make predictions on the test set
predictions = lr.predict(X_test)

# Print the test data and the corresponding predictions
print("Test data (CGPA):")
print(X_test)
print("\nActual Package:")
print(y_test)
# print("\nPredicted Package:")
# print(predictions)

# Plotting the original data and the regression line
plt.scatter(df['CGPA'], df['Package'], label='Data')
plt.plot(X_test, predictions, color='red', label='Regression Line')
plt.xlabel('CGPA')
plt.ylabel('Package (Lakhs)')
plt.title('CGPA vs Package')
plt.legend()
plt.show()

M=lr.coef_
B=lr.intercept_
#y=mx+b
print(lr.predict(X_test.iloc[1].values.reshape(1,1)))
print('LR prediction:',M*4.2+B)