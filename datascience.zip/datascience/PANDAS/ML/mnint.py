import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score

# Load dataset
df = pd.read_csv('D:\\PANDAS\\datasets\\Data Analytics\\digit_recognizer.csv')

# Split dataset into features and target
x = df.iloc[:, 1:]
y = df.iloc[:, 0]

# Split data into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# StandardScaler: Scale features
scaler = StandardScaler()
x_train = scaler.fit_transform(x_train)
x_test = scaler.transform(x_test)

# PCA: Reduce to 2 components for 2D scatterplot
pca = PCA(n_components=2)
x_train_2d = pca.fit_transform(x_train)
x_test_2d = pca.transform(x_test)

# KNN: Train model on the 2D transformed training set
knn = KNeighborsClassifier()
knn.fit(x_train_2d, y_train)

# Make predictions on the 2D transformed test set
y_pred = knn.predict(x_test_2d)

# Check accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")

# 2D Scatter plot of the PCA-transformed features
plt.figure(figsize=(10,6))
plt.scatter(x_train_2d[:, 0], x_train_2d[:, 1], c=y_train, cmap='viridis', s=5)
plt.colorbar(label='Digit Label')
plt.title('2D PCA Scatterplot of the Digits Dataset')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.show()
    