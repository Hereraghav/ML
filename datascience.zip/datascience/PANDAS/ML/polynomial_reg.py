import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression,SGDRegressor
from sklearn.preprocessing import PolynomialFeatures,StandardScaler
from sklearn.metrics import r2_score
from sklearn.pipeline import Pipeline

x=6* np.random.rand(200,1)-3
y=0.8 * x**2 + 0.9 *x+2+np.random.randn(200,1)

plt.plot(x,y,'b.')
plt.xlabel('x')
plt.ylabel('y')
plt.show()  


#TRAIN TEST SPLIT
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=2)
lr=LinearRegression()
lr.fit(x_train,y_train)
y_pred=lr.predict(x_test)
r2_score(y_test,y_pred)

plt.plot(x_train,lr.predict(x_train),color='r')
plt.plot(x,y,'b.')
plt.xlabel('x')
plt.ylabel('y')
plt.show()  


#Applying polynomial linear regression
#degree 2

poly=PolynomialFeatures(degree=2,include_bias=True)

x_train_trans=poly.fit_transform(x_train)
x_test_trans=poly.transform(x_test)

print(x_train[0])
print(x_train_trans[0])

#include bias parameter
lr=LinearRegression()
lr.fit(x_train_trans,y_train)
y_pred=lr.predict(x_test_trans)

r2_score(y_test,y_pred)
print(lr.coef_)
print(lr.intercept_)

x_new=np.linspace(-3,3,200).reshape(200,1)
x_new_poly=poly.transform(x_new)
y_new=lr.predict(x_new_poly)

plt.plot(x_new,y_new,'r-',linewidth=2,label='Predictions')
plt.plot(x_train,y_train,"b.",label='Training points')
plt.plot(x_test,y_test,'g.',label='Testing Points')
plt.xlabel('X')
plt.ylabel('Y')
plt.legend()
plt.show()

