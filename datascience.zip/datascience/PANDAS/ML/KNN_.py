import pandas as pd
import numpy as np
import os

# Load dataset
df = pd.read_csv('D:\\PANDAS\\datasets\\Data Analytics\\breast-cancer-wisconsin-data_data.csv')

# Drop unnecessary columns
df.drop(columns=['id', 'Unnamed: 32'], inplace=True)
print(df.shape)

# Split dataset into train and test sets
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(df.iloc[:, 1:], df.iloc[:, 0], test_size=0.2, random_state=2)

# Standardize features
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
x_train = scaler.fit_transform(x_train)
x_test = scaler.transform(x_test)

# Train the KNN classifier
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(x_train, y_train)

# Predict the target values for the test set
y_pred = knn.predict(x_test)

# Calculate and print the accuracy score
from sklearn.metrics import accuracy_score
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy score: {accuracy:.2f}')

scores=[]
for i in range(1,16):
    knn=KNeighborsClassifier (n_neighbors=i)
    knn.fit(x_train,y_train)
    y_pred=knn.predict(x_test)
    scores.append(accuracy_score(y_test,y_pred))

import matplotlib.pyplot as plt
plt.plot(range(1,16),scores)
plt.show()