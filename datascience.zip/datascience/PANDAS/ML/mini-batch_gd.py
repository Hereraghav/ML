# Mini batch gradient descent
from sklearn.datasets import load_diabetes
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import random
from sklearn.model_selection import train_test_split

# Load the diabetes dataset
data = load_diabetes()
x = data.data
y = data.target
print(x.shape)
print(y.shape)

# Split the dataset into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=2)

# Fit a linear regression model
reg = LinearRegression()
reg.fit(x_train, y_train)
print(reg.coef_)
print(reg.intercept_)
y_pred = reg.predict(x_test)
print("R2 Score:", r2_score(y_test, y_pred))

# Mini-batch gradient descent implementation
class GDregressor:
    def __init__(self, batch_size, learning_rate=0.01, epochs=100):
        self.intercept_ = None
        self.coef_ = None
        self.epochs = epochs
        self.lr = learning_rate
        self.batch_size = batch_size

    def fit(self, x_train, y_train):
        self.intercept_ = 0
        self.coef_ = np.ones(x_train.shape[1])

        for i in range(self.epochs):
            for j in range(int(x_train.shape[0] / self.batch_size)):
                idx = random.sample(range(x_train.shape[0]), self.batch_size)
                x_batch = x_train[idx]
                y_batch = y_train[idx]
                y_hat = np.dot(x_batch, self.coef_) + self.intercept_

                intercept_der = -2 * np.mean(y_batch - y_hat)
                self.intercept_ = self.intercept_ - (self.lr * intercept_der)

                coef_der = -2 * np.dot((y_batch - y_hat), x_batch) / self.batch_size
                self.coef_ = self.coef_ - (self.lr * coef_der)

        print(self.intercept_, self.coef_)

    def predict(self, x_test):
        return np.dot(x_test, self.coef_) + self.intercept_

# Create an instance of GDregressor and fit the model
mbr = GDregressor(batch_size=int(x_train.shape[0] / 10), learning_rate=0.01, epochs=50)
mbr.fit(x_train, y_train)
