import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_regression
import plotly.express as px
import plotly.graph_objects as go
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Generate regression data
x, y = make_regression(
    n_samples=100,
    n_features=2,
    n_informative=2,
    n_targets=1,
    noise=50,
    random_state=42
)

# Create DataFrame
df = pd.DataFrame({
    'feature1': x[:, 0],
    'feature2': x[:, 1],
    'target': y
})

# Print the shape of the DataFrame
print("DataFrame shape:", df.shape)

# Display the first few rows
print("\nFirst 5 rows of the DataFrame:")
print(df.head())

# Plot the data in 3D
fig = px.scatter_3d(df, x='feature1', y='feature2', z='target')
fig.show()

# Split the data into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=3)

# Train the Linear Regression model
lr = LinearRegression()
lr.fit(x_train, y_train)
y_pred = lr.predict(x_test)

# Evaluate the model
print('MAE:', mean_absolute_error(y_test, y_pred))
print('MSE:', mean_squared_error(y_test, y_pred))
print('R2 SCORE:', r2_score(y_test, y_pred))

# Generate a grid for the 3D surface plot
x_grid = np.linspace(x[:, 0].min(), x[:, 0].max(), 10)
y_grid = np.linspace(x[:, 1].min(), x[:, 1].max(), 10)
xgrid, ygrid = np.meshgrid(x_grid, y_grid)

# Combine grid points to predict values
grid_points = np.vstack([xgrid.ravel(), ygrid.ravel()]).T
z_pred = lr.predict(grid_points).reshape(xgrid.shape)

# Add the 3D surface plot to the scatter plot
fig = px.scatter_3d(df, x='feature1', y='feature2', z='target')
fig.add_trace(go.Surface(x=xgrid, y=ygrid, z=z_pred, colorscale='Viridis', opacity=0.7))
fig.show()
