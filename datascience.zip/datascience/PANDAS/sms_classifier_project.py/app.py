# import streamlit as st
# import pickle
# import string
# import nltk
# from nltk.stem.porter import PorterStemmer
# from nltk.corpus import stopwords
# ps=PorterStemmer()
# nltk.download('punkt_tab')
# nltk.download('stopwords')

# def transform_text(text):
#     text=text.lower()
#     text=nltk.word_tokenize(text)
#     y=[]
#     for i in text: 
#         if i.isalnum():
#             y.append(i)

#     text=y[:]
#     y.clear()
#     for i in text:
#         if i not in stopwords.words('english') and i not in string.punctuation:
#             y.append(i)
    
#     text=y[:]
#     y.clear()
#     for i in text:
#         y.append(ps.stem(i))

#     return ' '.join(y)
# tfidf=pickle.load(open('D:\\PANDAS\\sms_classifier_project.py\\vectorizer.pkl','rb'))
# model=pickle.load(open('D:\\PANDAS\\sms_classifier_project.py\\model.pkl','rb'))
# st.title('EMAIL/SMS SPAM CLASSIFIER')
# input_msg=st.text_area('Enter the message')
# if st.button('Predict'):
        
#     #1 preprocess
#     transformed_sms=transform_text(input_msg)
#     #2 vectorize
#     vector_input= tfidf.transform([transformed_sms])
#     #3 predict
#     result=model.predict(vector_input)[0]
#     #4 display
#     if result == 1:
#         st.header('spam')
#     else:
#         st.header('Not spam')
import streamlit as st
import pickle
import string
import nltk
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords

# Initialize the PorterStemmer and download NLTK data
ps = PorterStemmer()
nltk.download('punkt')
nltk.download('stopwords')

# Define the text transformation function
def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)
    text = [i for i in text if i.isalnum()]
    text = [i for i in text if i not in stopwords.words('english') and i not in string.punctuation]
    text = [ps.stem(i) for i in text]
    return ' '.join(text)

# Load the TF-IDF vectorizer and the model
tfidf = pickle.load(open('D:\\PANDAS\\sms_classifier_project.py\\vectorizer.pkl', 'rb'))
model = pickle.load(open('D:\\PANDAS\\sms_classifier_project.py\\best_model.pkl', 'rb'))

# Streamlit app title
st.title('EMAIL/SMS SPAM CLASSIFIER')

# Input text area for the user
input_msg = st.text_area('Enter the message')

# Prediction button
if st.button('Predict'):
    # Preprocess the input text
    transformed_sms = transform_text(input_msg)
    # Vectorize the preprocessed text
    vector_input = tfidf.transform([transformed_sms])
    # Predict using the loaded model
    result = model.predict(vector_input)[0]
    # Display the result
    if result == 1:
        st.header('Spam')
    else:
        st.header('Not Spam')
