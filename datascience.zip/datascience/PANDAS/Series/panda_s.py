#PANDAS is powerful tool to data analysis and manipulation
# two important topics are series and dataframe