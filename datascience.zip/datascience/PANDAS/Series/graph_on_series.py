import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file into a DataFrame
data = pd.read_csv('D:\\PANDAS\\datasets\\subs.csv') 
print(type(data))  # It is DataFrame type

# Check if the DataFrame has only one column
if data.shape[1] == 1:
    # Convert the DataFrame to a Series
    data_series = data.squeeze()
    print(type(data_series))  # It should be Series type

    # Print the Series
    print(data_series)

    # Plotting the Series
    data_series.plot()
    plt.title("Data Series Plot")
    plt.xlabel("Index")
    plt.ylabel("Values")
    plt.show()
else:
    print("DataFrame has more than one column, cannot convert to Series.")
    