import pandas as pd
import numpy as np
runs=[34,57,33,78,21,0,54]
runs_series=pd.Series(runs,name="Virat") # int data type
print(runs_series)
print("\n")

#SIZE
print(runs_series.size)
print("\n")

#Dtype
print(runs_series.dtype)
print("\n")

#name
print(runs_series.name)
print("\n")

#is_unique-to check duplicate item, if item are repeated -false else true
print(runs_series.is_unique)
print("\n")

#index= print all indexes
print(runs_series.index)
print("\n")

#Value- print all values
print(runs_series.values)
print("\n")