import pandas as pd
import numpy as np
marks ={  'Maths':68,
    'English':75,
    'SST':78,
    'Science':80
}
print(pd.Series(marks,name="Report card"))
#using indexing
marks['English']=90
print(marks)
#if item doesnt exist it will be added at tail

Runs=[34,57,33,78,21,0,54]
print(pd.Series(Runs)) 

#Slicing edit
Runs[1:2]=[99,99]
print(Runs)


