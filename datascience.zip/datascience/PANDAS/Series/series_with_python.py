#series with python functionalities
import numpy as np
import pandas as pd

data=pd.read_csv('D:\PANDAS\datasets\subs.csv') 
if data.shape[1] == 1:
    # Convert the DataFrame to a Series
    subs = data.squeeze()
    print(type(subs))  # It should be Series type
else:
    print("DataFrame has more than one column, cannot convert to Series.")

print(subs)

#len/type/dir/sorted/max/min
print(len(subs))
# print(dir(subs))
# print(sorted(subs))
print(max(subs))
print(min(subs))

