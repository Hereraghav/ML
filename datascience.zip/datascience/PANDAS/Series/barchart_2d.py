#Importing object type 2 column csv file
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

films = pd.read_csv('D:\\PANDAS\\datasets\\bollywood.csv')
# print("Dataframe: \n")
# print(films)

#converting it in series
movie=films.set_index('movie')['lead']
#set index = make the column index
print("\nSeries :")
print(movie)
print("\nType of the object:", type(movie))
bar=movie.value_counts().head(10)
# plot bar chart
bar.plot(kind='bar')
plt.title("Top actors")
plt.xlabel("Actors")
plt.ylabel("Numbers")
plt.show()