import pandas as pd
import numpy as np

x=pd.Series([12,34,56,76,43,14,10,40])

#indexing
print(x[1])

#negative indexing
#It doesnt work in integer, it only works where it is string integer

#SLICING
print(x[3:7])

#NEGATIVE SLICING
print(x[-2:])

#fancy indexing
print(x[[3,5,6]])

#indexing with labels -> fancy indexing
# example :- print(x[['Zindagi na milegi dobara']])
