import pandas as pd
import numpy as np

# Define the marks dictionary
marks = {
    'Maths': 68,
    'English': 75,
    'SST': 78,
    'Science': 80
}

# Create a Pandas Series from the dictionary
marks_series = pd.Series(marks, name="Report card")
print("Original Series:\n", marks_series)

# Perform arithmetic operation +-*/
adjusted_marks_series = 100 - marks_series
print("\nAdjusted Series (100 - marks):\n", adjusted_marks_series)
