import numpy as np
import pandas as pd

data=pd.read_csv('D:\PANDAS\datasets\subs.csv') 
print(type(data))
# it is dataframe type

#to change dataframe type to series
# Check if the DataFrame has only one column
if data.shape[1] == 1:
    # Convert the DataFrame to a Series
    data_series = data.squeeze()
    print(type(data_series))  # It should be Series type
else:
    print("DataFrame has more than one column, cannot convert to Series.")

print(data_series)

#Head and tails 
print(data_series.head())
# to print top 5 rows
#print(data_series.head(10)) # will list 10 matches
print("\n")
print(data_series.tail())
#last 5 , we can also write how many we want 

#sample
#Print 1 random row
print("\n")
print(data_series.sample(2))
#Used to check bias in data

#Booleanindexing
#find how many day subs added were more than 200
sub=data_series[data_series>200].size
print("Days with good subs addition :",sub)