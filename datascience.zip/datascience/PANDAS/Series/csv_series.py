#Importing object type 2 column csv file

import numpy as np
import pandas as pd

films = pd.read_csv('D:\\PANDAS\\datasets\\bollywood.csv')
print("Dataframe: \n")
print(films)

#converting it in series
movie=films.set_index('movie')['lead']
#set index = make the column index
print("\nSeries :")
print(movie)
print("\nType of the object:", type(movie))


#Value counts
#used to cound value frequency .
print("\n")
print(movie.value_counts())
#Ouput: Akshay Kumar        48
#       Amitabh Bachchan    45
#       Ajay Devgn          38

#sort_values()
print(movie.sort_index())
#Sort index values in decending order

#Membership operator
print('2 States (2014 film)' in movie)
#it works on index only not on values ,for value search :
# movie.values

# #Looping
# for i in movie:
#     print(i) #will show values

# #for index:
# for i in movie.index:
#     print(i)

#APply fucntion
print("Apply function:\n")
print(movie.apply(lambda x: x.split()[0].upper()))