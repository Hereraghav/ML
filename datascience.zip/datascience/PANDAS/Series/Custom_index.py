import numpy as np
import pandas as pd

marks=[78,95,65,88,91]
subject=['Maths','CS','Science','SS','Hindi']

# Here i want subjects to be index and marks as value

print(pd.Series(marks,index=subject))
#pd.series(value,index= item) default index wwill be repplaced

#We can also add name for list
print(pd.Series(marks,index=subject,name="Report Card"))