#Importing csv file with 2 columns
import pandas as pd
import numpy as np

Virat_ipl=pd.read_csv('D:\PANDAS\datasets\kohli_ipl.csv')
print("\nDataframe \n",Virat_ipl)
# 215 rows x 2 columns

IPL=Virat_ipl.set_index("match_no")['runs']

#print series
print("\nSeries")
print(IPL)
print("\nType of the object:", type(IPL))

#Sort values:
#Sort the values in ascending order
print("\n")
print(IPL.sort_values())
#To sort in decending order
#print(IPL.sort_values(ascending=False))

#To find highest score
print(IPL.sort_values(ascending=False).head(1).values[0])

#SORT_INDEX-> INPLACDE->TRUE
# print(IPL.sort_index(inplace=True))
#Do permanent change in data in descending order

#relational operator
condition=IPL >=50
print("matches with 50 or more :",condition)

#Boolean indexing
#find matches and score where 50 or more score
a=IPL[IPL>=50]
print("Matches with 50 more by kohli \n:",a)

#find ducks
duck=IPL[IPL==0] #can add .size to know total number of ducks

print("Matches with ducks :",duck)