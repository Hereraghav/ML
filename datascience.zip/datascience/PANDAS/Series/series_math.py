import pandas as pd
import numpy as np

Virat_ipl=pd.read_csv('D:\PANDAS\datasets\kohli_ipl.csv')
# 215 rows x 2 columns

IPL=Virat_ipl.set_index("match_no")['runs']

#print series
print("\nSeries")
print(IPL)
print("\nType of the object:", type(IPL))


#count() - total rows
print("Total matches : ",IPL.count())

#sum()-product()
#Total values
print("Total runs (values): ", IPL.sum())

#Mean, median,mode,std,var
print("Mean  (avg runs): ",IPL.mean())
print("Median: ",IPL.median())
print("STD:",IPL.std())
print("Mode :",IPL.mode()) #most occuring value 
print("Variance: ",IPL.var())

#min /max
print("Max runs in inning:",IPL.max() )
print("Lowest score:",IPL.min())

#Descibe: it lists all mathematical calculations

print("\n")
print("Overall:\n",IPL.describe())