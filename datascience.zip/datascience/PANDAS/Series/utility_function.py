#Importing csv file with 2 columns
import pandas as pd
import numpy as np
import sys
Virat_ipl=pd.read_csv('D:\PANDAS\datasets\kohli_ipl.csv')
# print("\nDataframe \n",Virat_ipl)
# 215 rows x 2 columns

IPL=Virat_ipl.set_index("match_no")['runs']
print(sys.getsizeof(IPL))

#astype - used to change size
print(sys.getsizeof(IPL.astype('int16')))

#between- check values in a range.
print(IPL.between(51,99).sum())

#clip-trim Given range 
# print(IPL.clip(25,75))
