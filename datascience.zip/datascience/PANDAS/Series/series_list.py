#Series is pandas is 1d type of array for holding data
import pandas as pd
import numpy as np
#it is rec. to install numpy also with pandas as it is built on numpy

country=['India','USA','Australia','South Africa','New zealand']
print(pd.Series(country))
# Series will always give Values and its index.
# Object data type is string 99% in pandas

Runs=[34,57,33,78,21,0,54]
print(pd.Series(Runs)) # int data type
print("Type is: ",type(Runs))

    
