import pandas as pd
import numpy as np

# Creating a dictionary with 6 columns and 15 rows of data
data_dict = {
    'ProductID': range(101, 116),  # Product IDs from 101 to 115
    'ProductName': [
        'Laptop', 'Smartphone', 'Tablet', 'Headphones', 'Charger',
        'Camera', 'Smartwatch', 'Printer', 'Keyboard', 'Mouse',
        'Monitor', 'External HDD', 'USB Cable', 'Webcam', 'Speaker'
    ],
    'Category': [
        'Electronics', 'Electronics', 'Electronics', 'Accessories', 'Accessories',
        'Electronics', 'Wearables', 'Office Supplies', 'Accessories', 'Accessories',
        'Electronics', 'Storage', 'Accessories', 'Accessories', 'Accessories'
    ],
    'QuantitySold': np.random.randint(1, 50, 15),  # Random quantities sold between 1 and 50
    'UnitPrice': [
        800, 600, 300, 50, 20,
        500, 200, 150, 30, 25,
        250, 100, 10, 35, 60
    ],
}

# data_dict['TotalRevenue'] = np.array(data_dict['QuantitySold']) * np.array(data_dict['UnitPrice'])

# Creating DataFrame
shop = pd.DataFrame(data_dict)
print("Generated DataFrame:\n", shop)

#Maths functions

#Sum - col will do sum
print("\nSum: \n" ,shop[['QuantitySold', 'UnitPrice']].sum())
#for row wise sum: .sum(axis=1) 
print("\n")

#Mean
print("\nMean: \n" ,shop[['QuantitySold', 'UnitPrice']].mean())
print("\n")
#Median
print("\nMedian: \n" ,shop[['QuantitySold', 'UnitPrice']].median())
print("\n")
#std
print("\nStandard deviation: \n" ,shop[['QuantitySold', 'UnitPrice']].std())
print("\n")
#variance
print("\nSum: \n" ,shop[['QuantitySold', 'UnitPrice']].var())
print("\n")

#Set index
shop.set_index("ProductID",inplace=True)
print(shop)

#loc
print("Printing using label loc :\n",shop.loc[102])