import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ipl=pd.read_csv("D:\PANDAS\datasets\ipl-matches.csv")
print(ipl.head(2))
print(ipl.info()) #info of all cols


#filtering a dataframe

#all winners of IPL
winner=ipl['MatchNumber']=='Final'
new_df=(ipl[winner])
print(new_df[['Season','WinningTeam']])
print("\n")

#How many super over finishes are there
print("Total super over macthes:",ipl[ipl["SuperOver"]=='Y'].shape[0])
SO=ipl[ipl["SuperOver"]=='Y'][["Team1","Team2",'WinningTeam']]
print(SO)
print("\n")

#how many matches CSK in Kolkata
csk_in_Kol=ipl[(ipl["WinningTeam" ]== "Chennai Super Kings" ) & (ipl["City"]=='Kolkata')]
print(csk_in_Kol)
print("\n")

# Toss winner is  Match winner in percent
Percent=ipl[ipl["TossWinner"] == ipl["WinningTeam"]].shape[0]/ipl.shape[0]*100
print("Matches in which Toss winner is match winner :",Percent)

#Funtion that return the track record of 2 team against each other

#ASTYPE
#used to reduce memory space
#ipl['Team1']=ipl['Team1'].astype("category")

#Find player with most potm in IPL
potm=(ipl[ipl['MatchNumber'].str.isdigit()]['Player_of_Match'].value_counts())
print("Player with most POTM award: ",potm.head(1))
print("\n")

#Toss decision plot
toss=ipl['TossDecision'].value_counts()
toss.plot(kind='pie')
# plt.show() 
print("\n")

#Match each team played.
print((ipl['Team1'].value_counts()+ ipl["Team2"].value_counts()).sort_values(ascending=False))

# #Last match played by VK in delhi
# ipl['all players']=ipl['Team1Players'] + ipl['Team2Players']
# def Vk(player_list):
#     return 'V Kohli' in player_list
# ipl['Vk']=ipl["all players"].apply[Vk]
# print(ipl[(ipl["City"]=='Delhi') & (ipl['Vk']==True)].drop_duplicates(subset=['City','Vk'],keep='first'))
      