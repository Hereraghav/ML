#2D STRUCTURE of Data with rows and col in tabular form is dataframe
#Series is single column in dataframe 
#Every row of data frame is also series.
import pandas as pd
import numpy as np
#Using Lists
student_data=[
    [100,80,10],
    [90,70,7],
    [120,100,14],
    [80,50,2]
]

#creating data frame
df=pd.DataFrame(student_data,columns=['Iq','marks','package'])
print("Lists: \n",df)
print("\n")

#Using dictionary
student_dict={
    'marks':[90,80,70,60],
    'Package':[10,12,4,6],
    'IQ':[100,90,60,80]

}
dictionary=pd.DataFrame(student_dict)
print("Dictionary: \n",dictionary)

#rename- used to rename a column  in dict
print(dictionary.rename(columns={'marks':'percent','Package':'lpa'}))