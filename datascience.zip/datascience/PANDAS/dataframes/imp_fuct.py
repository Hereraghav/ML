import pandas as pd
import numpy as np

student_data=[
    [100,80,10],
    [90,70,7],
    [120,100,14],
    [80,50,2],
    [80,50,2]
]

#creating data frame
marks=pd.DataFrame(student_data,columns=['Iq','marks','package'])
print("Lists: \n",marks)
print("\n")

#value counts( S & df)
print("Value counts:\n",marks.value_counts())
print("\n")

#sort_values -> ascending ->na_position-> inplace ->multiple cols
x=pd.Series([5,6,9,1,4,2,3])
print(x.sort_values())
print("\n")

#np.nan is Null value   
#unique and nunique
uni=pd.Series([1,1,2,2,4,4,5,6,6])
print("Ünique:",uni.unique())
print("NotUnique:",uni.nunique())
print("\n")

#NotNull/isnull
nv=pd.Series([2,3,4,5,5,6,np.nan,np.nan,8])
print("NUll values are :",nv[nv.isnull()]) # will check null value
print("Not null values are :",nv[nv.notnull()]) # will give not null val

#hasnans-will check in complete col that is there any nulll or not
print("Is there any null value:",nv.hasnans)
print("\n")

#dropna -used to delete Null values
print("DropNa:\n",nv.dropna())
print("\n")
#dropna in DATAFRAME - 
# print(movie.dropna(how=any))- will delete entire row if any null value find 
# print(movie.dropna(how=all)) - will only delete row if all col in that row is null
#print(movie.dropna(subset=['name']))- will delete the row if name col has null value


#fillna- used to fill null value
print("Fillna:\n",nv.fillna(0))
print("\n")

#drop_duplicates()- remove duplicated items
print("Drop duplicates : \n",nv.drop_duplicates())
print("\n")

#drop rows /series
print("Drop rows/ series :\n",nv.drop(index=[2,3]))
print("\n")

#drop col
# print(movie.drop(columns=["Mvoie",'Year']))

# apply-(series & df) 
def sigmoid(value):
    return 1/1 +np.exp(-value)

print("Use of apply function(sigmoid): \n",nv.apply(sigmoid))
print("\n")