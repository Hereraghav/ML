import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

run=pd.read_csv('D:\\PANDAS\\datasets\\batsman_runs_ipl.csv')


#Rank , by default - ascending
run['Batting_rank']=run['batsman_run'].rank(ascending=False)
# print(run.sort_values('Batting_rank').head(15))

#set_index- dataframe to change index
run.set_index('batter',inplace=True)
print(run)

#reset_index-reverse the set index
# run.reset_index('batter',inplace=True)