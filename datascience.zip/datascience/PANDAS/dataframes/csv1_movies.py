import pandas as pd
import numpy as np

movie=(pd.read_csv("D:\PANDAS\datasets\movies.csv"))
print("\n")

#attributes

#Shape-knowing rows and cols
print("Rows and columns:-",movie.shape)
print("\n")

#DTYPES- Tells data types of all cols
print("DataTypes:",movie.dtypes)
print("\n")

#Index-  Caculates rows
print("Index :",movie.index)
print("\n")

#Columns- Fetches all cols
print("Columns :",movie.columns)
print("\n")

#values- gives values of each index

#Head and Tail -default is 5
print("Top 5: ",movie.head())
print("\n")
print("Bottom 5:",movie.tail())
print("\n")

#Sample- randomly will list 1
#uSED IN bias condition

print("Sample :",movie.sample())
print("\n")

#Info -gives high level information about dataframe
print("Info: ",movie.info())
print("\n")

#describe-Mathematical summary
print("describe :",movie.describe())
print("\n")

#isnull-used to check null valules
print("NUll values:",movie.isnull().sum())
 #sum() will tell sum of missing values in each col
 #will get boolen values-t/f
print("\n") 

#duplicated-finds duplicate values
#it shoudlnt be there.
print("Duplicated items: ",movie.duplicated().sum()) #.sum() to check total as duplicated shows BOOL
print("\n")

#selecting single col
print("Movie title:\n",movie['title_x'])
print("\n")
#fetch multiple cols
print("Multiple cols:\n",movie[['actors','year_of_release']])
print("\n")

#Searching
#iloc-searches using index position
#loc-searches using index labels

print("Searching by iloc (position): \n",movie.iloc[0]) #can also use [0:10] for 9 movies
print("\n")

#select both row n col

print("Searching by iloc (position): \n",movie.iloc[0:3,0:3]) #3 col nd 3 rows 
print("\n")

#MOvies with rating higher than 8 and votes >10,000
dt=movie[(movie["imdb_rating"]>8) & (movie["imdb_votes"]>10000)].shape[0]
print("DATA of MOvies with rating higher than 8 and votes >10,000:",dt)

#Action movies with rating above 7.5
action=movie["genres"].str.split('|').apply(lambda x:'Action' in x)
#or
#action=movie["genres"].str.split('|').contains("Action")
action2=movie["imdb_rating"]>7.5    
print("Action movies with rating above 7.5",movie[action & action2])

#sort_values
print("Sorting:\n",movie.sort_values('title_x',ascending=False))

#sorting by year and alphabet
print("Sorting by Year nd alphabet: \n",movie.sort_values(['year_of_release','title_x']))

#rename(dataframe)-index
print(movie.rename(columns={
    'imdb_id':'imdb',
    'poster_path':'link'
}))

#rename index
print(movie.rename(index={
    'Uri: The Surgical Strike ':'Uri'
}))