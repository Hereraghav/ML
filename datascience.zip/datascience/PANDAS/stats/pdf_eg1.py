import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df=sns.load_dataset('iris')
# print(a.head())

sns.kdeplot(data=df,x='petal_length',hue='species' )
plt.show()

titanic=sns.load_dataset('titanic')
# print(titanic.head())

#using pdf to analyze survived and age col
sns.kdeplot(data=titanic,x='age',hue='survived')
plt.show()