import pandas as pd
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.model_selection import cross_val_score

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import FunctionTransformer
from sklearn.compose import ColumnTransformer

# Load dataset
df = sns.load_dataset('titanic')

# Select relevant columns and handle missing values
tempdf = df[['survived', 'age', 'fare']].copy()  # Explicitly create a copy to avoid the warning
tempdf['age'].fillna(tempdf['age'].mean(), inplace=True)
tempdf['fare'].fillna(tempdf['fare'].mean(), inplace=True)

# Split the data into training and testing sets
x = tempdf.iloc[:, 1:3]
y = tempdf.iloc[:, 0]
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# Plotting Age
plt.figure(figsize=(12, 7))

# Age PDF plot
plt.subplot(221)
sns.histplot(x_train['age'], kde=True)
plt.title('Age PDF')

# Age QQ plot
plt.subplot(222)
stats.probplot(x_train['age'], dist='norm', plot=plt)
plt.title('Age QQ plot')

# Plotting Fare
# Fare PDF plot
plt.subplot(223)
sns.histplot(x_train['fare'], kde=True)
plt.title('Fare PDF')

# Fare QQ plot
plt.subplot(224)
stats.probplot(x_train['fare'], dist='norm', plot=plt)
plt.title('Fare QQ plot')

plt.tight_layout()  # Adjust layout to prevent overlap
plt.show()

clf=LogisticRegression()
clf2=DecisionTreeClassifier()
clf.fit(x_train,y_train)
clf2.fit(x_train,y_train)

y_pred=clf.predict(x_test)
y_pred1=clf2.predict(x_test)

print('Accuracy Logistic reg:',accuracy_score(y_test,y_pred))
print('Accuracy Decision tree:',accuracy_score(y_test,y_pred1))
print('\n**********\n')

trf=FunctionTransformer(func=np.log1p)
x_test_transformed=trf.transform(x_test)
x_train_transformed=trf.fit_transform(x_train)

clf=LogisticRegression()
clf2=DecisionTreeClassifier()
clf.fit(x_train_transformed,y_train)
clf2.fit(x_train_transformed,y_train)

y_pred=clf.predict(x_test_transformed)
y_pred1=clf2.predict(x_test_transformed)

print('Accuracy Logistic reg:',accuracy_score(y_test,y_pred))
print('Accuracy Decision tree:',accuracy_score(y_test,y_pred1))
print('\n**********\n')

x_transformed=trf.fit_transform(x)
clf=LogisticRegression()
clf2=DecisionTreeClassifier()
print("LR:",np.mean(cross_val_score(clf,x_transformed,y,scoring='accuracy',cv=10)))
print("DTC:",np.mean(cross_val_score(clf2,x_transformed,y,scoring='accuracy',cv=10)))

plt.figure(figsize=(10,6))
plt.subplot(121)
stats.probplot(x_train['fare'],dist='norm',plot=plt)
plt.title('Age before log')

plt.subplot(122)
stats.probplot(x_train_transformed['fare'],dist='norm',plot=plt)
plt.title('Age after log')
plt.show()