import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import shapiro, levene, ttest_ind

# Load the Titanic dataset
df = sns.load_dataset('titanic')

# Extract the ages of males and females
pop_male = df[df['sex'] == 'male']['age'].dropna()
pop_female = df[df['sex'] == 'female']['age'].dropna()

# Take random samples of size 25 from both populations
sample_male = pop_male.sample(25)
sample_female = pop_female.sample(25)

# Set the significance level
alpha = 0.05

# Perform Shapiro-Wilk test for normality
shapiro_male = shapiro(sample_male)
shapiro_female = shapiro(sample_female)
print('Shapiro-Wilk test for males:', shapiro_male)
print('Shapiro-Wilk test for females:', shapiro_female)

# Perform Levene's test for equal variances
levene_test = levene(sample_male, sample_female)
print('Levene\'s test:', levene_test)

# Perform two-sample t-test (one-tailed)
t_statistic, p_value = ttest_ind(sample_male, sample_female)
print('t-statistic:', t_statistic)
print('p-value (one-tailed):', p_value / 2)
print('\n')

# Decision based on the p-value
if p_value / 2 < alpha:
    print('Reject the null hypothesis: Mean age of males is greater than females')
else:
    print('Fail to reject the null hypothesis')
