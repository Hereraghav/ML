import numpy as np

# Define the vectors
a = np.array([1, 2, 3])
b = np.array([4, 5, 6])
c = np.array([7, 8, 9])

# Cumulative Property: a . (b + c) = (a . b) + (a . c)
sum_b_c = b + c
dot_a_sum_b_c = np.dot(a, sum_b_c)
dot_a_b = np.dot(a, b)
dot_a_c = np.dot(a, c)
cumulative_check = dot_a_b + dot_a_c

# Distributive Property: (a + b) . c = (a . c) + (b . c)
sum_a_b = a + b
dot_sum_a_b_c = np.dot(sum_a_b, c)
distributive_check = np.dot(a, c) + np.dot(b, c)

# Print results
print("Cumulative Property Check:")
print(f"a . (b + c) = {dot_a_sum_b_c}")
print(f"(a . b) + (a . c) = {cumulative_check}")
print(f"Match: {np.isclose(dot_a_sum_b_c, cumulative_check)}")

print("\nDistributive Property Check:")
print(f"(a + b) . c = {dot_sum_a_b_c}")
print(f"(a . c) + (b . c) = {distributive_check}")
print(f"Match: {np.isclose(dot_sum_a_b_c, distributive_check)}")
