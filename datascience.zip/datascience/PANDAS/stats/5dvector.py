import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.spatial.distance import euclidean

# Generate 5 random 3D vectors
vectors = np.random.rand(5, 3)

# Assign random class (0 or 1) to each vector
classes = np.random.randint(0, 2, 5)

# Plot the vectors on a 3D matplotlib graph
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot each vector with its corresponding class
for vec, cls in zip(vectors, classes):
    color = 'r' if cls == 1 else 'b'
    ax.quiver(0, 0, 0, vec[0], vec[1], vec[2], color=color, label=f'Class {cls}')

# Get user input
try:
    query_vector = np.array(list(map(float, input('Enter the query point (3D vector) separated by space: ').split())))
    if query_vector.shape[0] != 3:
        raise ValueError("The input vector must have exactly 3 components.")
except ValueError as e:
    print(f"Invalid input: {e}")
    exit()

# Calculate distances from the query vector to the 5 vectors and find the nearest neighbor
distances = [euclidean(query_vector, vec) for vec in vectors]
nearest_neighbour_index = np.argmin(distances)

# Output the class of the nearest neighbor
print(f'The class of the nearest neighbor is: {classes[nearest_neighbour_index]}')

# Plot the query vector with a different color
ax.quiver(0, 0, 0, query_vector[0], query_vector[1], query_vector[2], color='g', label='Query Vector')

# Set axis labels
ax.set_xlabel('X-axis')
ax.set_ylabel('Y-axis')
ax.set_zlabel('Z-axis')

# Add a legend
ax.legend()

plt.show()
