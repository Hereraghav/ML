#PMF- gives Probability at particular point
import pandas as pd
import matplotlib.pyplot as plt
import random

# Simulate rolling one six-sided die 10,000 times
L_one_die = [random.randint(1, 6) for _ in range(10000)]

# Simulate rolling two six-sided dice 10,000 times and summing their results
L_two_dice = [random.randint(1, 6) + random.randint(1, 6) for _ in range(10000)]

# Probability distribution for one die
s_one_die = (pd.Series(L_one_die).value_counts() / pd.Series(L_one_die).value_counts().sum()).sort_index()

# Probability distribution for two dice
s_two_dice = (pd.Series(L_two_dice).value_counts() / pd.Series(L_two_dice).value_counts().sum()).sort_index()

# Plotting both distributions side by side
plt.figure(figsize=(14, 6))

# Plot for one die
plt.subplot(1, 2, 1)
s_one_die.plot(kind='bar', color='skyblue')
plt.title('Probability Distribution of One Six-Sided Die Rolled 10,000 Times')
plt.xlabel('Result of One Die')
plt.ylabel('Probability')
plt.xticks(rotation=0)

# Plot for two dice
plt.subplot(1, 2, 2)
s_two_dice.plot(kind='bar', color='lightgreen')
plt.title('Probability Distribution of the Sum of Two Six-Sided Dice Rolled 10,000 Times')
plt.xlabel('Sum of Two Dice')
plt.ylabel('Probability')
plt.xticks(rotation=0)

plt.tight_layout()
plt.show()
