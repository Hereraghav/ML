import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import shapiro
import scipy.stats as stats

df=sns.load_dataset('titanic')
# print(df.info())
pop=df['age'].dropna()
sample_age=pop.sample(25).values

#H0-Mean age is 35
#H1-Mean is less than 35

shapiro_age=shapiro(sample_age)
print('Shapiro:',shapiro_age)
print('\n')
pop_mean=35
t_statistic,p_value=stats.ttest_1samp(sample_age,pop_mean)
print('t stat:',t_statistic)
print('p-value: ',p_value/2)
print('\n')

alpha=0.05
if p_value<alpha:
    print('REJECT NULL HYPOTHESIS')
else:
    print('Failed to reject null hypothesis')
      