#PDF- happen on continous random variable
#y axis represents prob density

#PARAMETRIC DENSITY ESTIMATION
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
from scipy.stats import norm
import seaborn as sns

# Generate a sample from a normal distribution
sample = norm.rvs(loc=50, scale=5, size=1000)

# Calculate the sample mean and standard deviation
sample_mean = sample.mean()
sample_std = sample.std()

# Plot the histogram of the sample
plt.figure(figsize=(10, 6))
plt.hist(sample, bins=10, alpha=0.6, color='g', label='Sample Histogram')

# Create a normal distribution based on the sample mean and std
dist = norm(sample_mean, sample_std)

# Generate values for the x-axis
values = np.linspace(sample.min(), sample.max(), 100)

# Calculate the PDF for these values
probabilities = dist.pdf(values)

# Plot the density histogram and the PDF
plt.hist(sample, bins=10, density=True, alpha=0.6, color='g', label='Density Histogram')
plt.plot(values, probabilities, 'r-', label='PDF')
plt.title('Parametric Density Estimation')
plt.xlabel('Value')
plt.ylabel('Density')
plt.legend()
plt.show()

# Using seaborn to plot the distribution
sns.displot(sample, kde=True)
plt.title('KDE Plot of the Sample')
plt.show()
