import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

n=10 #no of trails
p=0.9 #prob of success
size=1000
bino_dist=np.random.binomial(n,p,size)
plt.hist(bino_dist,density=True)
plt.show()