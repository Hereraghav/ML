#Euclidiean distance
import numpy as np
import pandas as pd

A=np.array([1,2,3,4,5])
B=np.array([6,7,8,9,10])

#Difference vector
diff=A-B

#Calculate eucladien distance
distance=np.linalg.norm(diff)
print('Euclidean distance between A and B: ',distance)
