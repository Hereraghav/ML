#CDF-Gives all the probability of points upto x 
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt

# Simulate rolling two six-sided dice 10,000 times
L = []
for i in range(10000):
    L1 = random.randint(1, 6)
    L2 = random.randint(1, 6)
    L.append(L1 + L2)

# Display the first 5 results
print(L[:5])

# Calculate the probability distribution of the sums
s = (pd.Series(L).value_counts() / pd.Series(L).value_counts().sum()).sort_index()

# Calculate and plot the cumulative distribution function (CDF)
np.cumsum(s).plot(kind='bar', color='orange')
plt.title('Cumulative Distribution Function of Two Dice Sum')
plt.xlabel('Sum of Two Dice')
plt.ylabel('Cumulative Probability')
plt.show()
