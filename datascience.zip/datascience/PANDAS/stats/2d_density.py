import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df=sns.load_dataset('iris')
# print(a.head())

sns.jointplot(data=df,x='petal_length',y='sepal_length',kind='kde',fill=True,cbar=True )
plt.show()
