import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the Titanic dataset
df = pd.read_csv('D:\\PANDAS\\datasets\\session22\\titanic.csv')

# Plot the distribution of the Fare column
df['Fare'].plot(kind='kde')
plt.title('KDE of Fare')
plt.show()

# Take 100 samples of size 50 from the Fare column
samples = []
for i in range(100):
    samples.append(df['Fare'].dropna().sample(50).values.tolist())

# Convert samples to a NumPy array and calculate the means of the samples
samples = np.array(samples)
sampling_means = samples.mean(axis=1)

# Plot the distribution of the sampling means
sns.kdeplot(sampling_means)
plt.title('KDE of Sampling Means')
plt.show()

# Calculate the mean and standard error of the sampling distribution
mean_of_sampling_means = sampling_means.mean()
std_error = sampling_means.std() / np.sqrt(50)

# Calculate the 95% confidence interval
lower_limit = mean_of_sampling_means - 2 * std_error
upper_limit = mean_of_sampling_means + 2 * std_error
print('95% Confidence Interval:', lower_limit, '<-->', upper_limit)
print('\n')
print('Actual mean of Fare:', df['Fare'].mean())
