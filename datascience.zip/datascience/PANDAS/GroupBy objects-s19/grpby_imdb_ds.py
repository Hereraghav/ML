import pandas as pd
import numpy as np

movie=pd.read_csv("D:\PANDAS\datasets\imdb-top-1000.csv")
# print(movie)

#GroupBy
#Lets group all genres movies seperatly
genre=movie.groupby('Genre')

#Applying built in aggregation function on  group by objects.

#find top 3 genre of total earning
print(genre['Gross'].sum().sort_values(ascending=False).head(3))
print("\n")

#find genre with highest imdb
print(genre['IMDB_Rating'].mean().sort_values(ascending=False).head(3))  
print("\n")

#find movies with most popular director
print("Most popular director:\n",movie.groupby('Director')['No_of_Votes'].sum().sort_values(ascending=False).head(3))
print("\n")

#most movies by each actor
print(movie.groupby('Star1')['Series_Title'].count().sort_values(ascending=False).head(3))
print("\n")
#find total number of group -len
print("length is :",len(genre))
print("\n")

#find row in groups
print("Size is :",genre.size())
print("\n")

#first() and last()
# print("first :",genre.first())
# print("last item :",genre.last())
#print("Any n number value :",genre.nth(7)) will should 7th number movie of each genre
# print("\n")

#Get group- used to view all item in a specific group
print(genre.get_group('Fantasy') ) # will list all movies in horror genres
print("\n")

#groups
# print(genre.groups) To print index position of al value in each genre

#descibe- general maths values
print(genre.describe())
print("\n")

#AGGREGATE FUNCTIONS
print("******************************************************************************")
print("\n")

# print(genre.agg({
#     'Runtime':'mean',
#     'IMDB_Rating':'mean',
#     'No_of_Votes':'sum',
#     'Gross':'sum',
#     'Metascore':'min'
# }))

#passing list
#for each col min max mean
# print(genre.agg(['min','max','mean']))

#adding both syntax

print(genre.agg({
    'Runtime':['min','max','mean'],
    'IMDB_Rating':['min','max','mean'] ,
    'No_of_Votes':['min','max','mean'],
    'Gross':'sum',
    'Metascore':'min' }))
print("\n")

#Find highest rated movie of each genre
# df= pd.DataFrame(columns=movie.columns)
# for group,data in genre:
#     df=df.append(data[data['IMDB_Rating']== data['IMDB_Rating'].max()])
# print("\n")


#split(apply) -> combine
#builtin -> apply

#find number of movies starting with A
def a(group):
    return group['Series_Title'].str.startswith('A').sum()

print("Movies starting with A:\n",genre.apply(a))

#find ranking on each movie on base of IMDB

def rank(group):
    group['Genre rank'] = group['IMDB_Rating'].rank(ascending=False)
    return group

print(genre.apply(rank))
print("\n")

#find normalized imdb rating grp wise
#FORMULAE-xnormalized = (x - xminimum) / range of x

def normal(group):
    group['Normalized']=(group['IMDB_Rating'] -group['IMDB_Rating'].min())/(group['IMDB_Rating'].max()-group['IMDB_Rating'].min())
    return group
print(genre.apply(normal))
print("\n")
#groupBY on Mutiple cols
duo=movie.groupby(['Director','Star1'])
print(duo.size().sort_values(ascending=False))
print("\n")


#Actor+director earned most
print(duo['Gross'].sum().sort_values(ascending=False).head(3))
print("\n")
#find the best in terms of metacscore avg ,actor-genre.combo
print(movie.groupby(['Star1','Genre'])['Metascore'].mean().reset_index().sort_values('Metascore',ascending=False).head())
print("\n")

