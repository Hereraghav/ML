print(genre.agg({
#     'Runtime':'mean',
#     'IMDB_Rating':'mean',
#     'No_of_Votes':'sum',
#     'Gross':'sum',
#     'Metascore':'min'
# }))
