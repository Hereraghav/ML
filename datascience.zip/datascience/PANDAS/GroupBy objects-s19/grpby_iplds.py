import numpy as np
import pandas as pd

ipl=pd.read_csv("D:\PANDAS\datasets\deliveries.csv")
# print(ipl.head())

#GroupBy practice 5 questions

#Top5 batter runs
print("Top runs :\n",ipl.groupby('batsman')['batsman_runs'].sum().sort_values(ascending=False).head(10))
print("\n")

#Batter with most sixes
six=ipl[ipl['batsman_runs']==6]
print("Batter with most sixes:\n",six.groupby('batsman')['batsman'].count().sort_values(ascending=False).head(2))
print("\n")


#Batter with most boundaries in last 5 overs
over=ipl[ipl['over']>15]
boundry=over[(over['batsman_runs']==4) | (over['batsman_runs']==6)]
print("batter with most boundaries in last 5 overs:\n",boundry.groupby('batsman')['batsman'].count().sort_values(ascending=False).head(5))
print("\n")

#Find ABD record against each team
a=ipl[ipl['batsman']=='AB de Villiers']
print("ABD RECORD AGAINST EACH TEAM :\n",a.groupby('bowling_team')['batsman_runs'].sum())
print('\n')

#function of highest score of any batter
def highest(batsman):
    df=ipl[ipl['batsman']==batsman]
    return df.groupby('match_id')['batsman_runs'].sum().sort_values(ascending=False).head(1).values[0]

print(highest('V Kohli'))